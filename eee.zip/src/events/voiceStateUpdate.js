const { Events, ChannelType, PermissionFlagsBits } = require('discord.js');
const { db } = require('../database');
const { guilds, bytepods, bytepodAutoWhitelist, bytepodUserSettings, bytepodActiveSessions, bytepodVoiceStats, bytepodSessionHistory } = require('../database/schema');
const { eq, and } = require('drizzle-orm');
const logger = require('../utils/logger');
const embeds = require('../utils/embeds');
const { checkBotPermissions } = require('../utils/permissionCheck');
const { getControlPanel } = require('../components/bytepodControls');
const { dbLog } = require('../utils/dbLogger');
const { createSummaryEmbed } = require('../utils/bytepodSummaryUtil');
const { getRandomPodName } = require('../utils/podNameGenerator');

// Helper to get pod state (lock status, whitelist, etc.)
function getPodState(channel) {
    const { PermissionFlagsBits } = require('discord.js');
    const isLocked = channel.permissionOverwrites.cache.get(channel.guild.id)?.deny.has(PermissionFlagsBits.Connect);
    const limit = channel.userLimit;

    const whitelist = [];
    const coOwners = [];

    channel.permissionOverwrites.cache.forEach((overwrite) => {
        if (overwrite.type !== 1) return; // Member only

        // Co-Owner: ManageChannels
        if (overwrite.allow.has(PermissionFlagsBits.ManageChannels)) {
            coOwners.push(overwrite.id);
        }

        // Whitelist: Connect = true
        if (overwrite.allow.has(PermissionFlagsBits.Connect)) {
            if (!coOwners.includes(overwrite.id)) {
                whitelist.push(overwrite.id);
            }
        }
    });

    return { isLocked, limit, whitelist, coOwners };
}

// Helper to finalize a voice session and update stats
async function finalizeVoiceSession(session, client) {
    const durationSeconds = Math.floor((Date.now() - session.startTime) / 1000);

    // Delete active session
    await dbLog.delete('bytepodActiveSessions',
        () => db.delete(bytepodActiveSessions)
            .where(eq(bytepodActiveSessions.id, session.id)),
        { sessionId: session.id, userId: session.userId, guildId: session.guildId }
    );

    // Upsert aggregate stats
    const existing = await dbLog.select('bytepodVoiceStats',
        () => db.select().from(bytepodVoiceStats)
            .where(and(
                eq(bytepodVoiceStats.userId, session.userId),
                eq(bytepodVoiceStats.guildId, session.guildId)
            )).get(),
        { userId: session.userId, guildId: session.guildId }
    );

    if (existing) {
        await dbLog.update('bytepodVoiceStats',
            () => db.update(bytepodVoiceStats)
                .set({
                    totalSeconds: existing.totalSeconds + durationSeconds,
                    sessionCount: existing.sessionCount + 1
                })
                .where(eq(bytepodVoiceStats.id, existing.id)),
            { userId: session.userId, guildId: session.guildId, durationSeconds }
        );
    } else {
        await dbLog.insert('bytepodVoiceStats',
            () => db.insert(bytepodVoiceStats).values({
                userId: session.userId,
                guildId: session.guildId,
                totalSeconds: durationSeconds,
                sessionCount: 1
            }),
            { userId: session.userId, guildId: session.guildId, durationSeconds }
        );
    }

    // Track activity streak (convert seconds to minutes)
    const durationMinutes = Math.floor(durationSeconds / 60);
    if (durationMinutes > 0 && client.activityStreakService) {
        try {
            await client.activityStreakService.recordActivity(
                session.userId,
                session.guildId,
                'voice',
                durationMinutes
            );
        } catch (error) {
            logger.error('Activity streak tracking error:', error);
            // Don't crash on tracking errors, just log
        }
    }

    return durationSeconds;
}

// --- OWNERSHIP TRANSFER SYSTEM ---
// In-memory map to track pending ownership transfers: channelId -> timeoutId
const pendingOwnershipTransfers = new Map();
const OWNERSHIP_TRANSFER_DELAY_MS = 5 * 60 * 1000; // 5 minutes

// In-memory guard to coalesce duplicate join-hub events while one pod is being created.
const pendingPodCreations = new Set();

// --- SESSION STATS TRACKING ---
// Track pod statistics in memory for session summaries
// podId -> { peakUsers: number, currentUsers: number, visitors: Set<string> }
const podStatsTracker = new Map();

/**
 * Transfer ownership of a BytePod to a new member
 */
async function transferOwnership(channel, podData, newOwnerId, client) {
    const guild = channel.guild;
    const oldOwnerId = podData.ownerId;

    try {
        logger.debug(`[Transfer] Step 1: Capturing current pod configuration`);
        // Capture current whitelist and co-owners BEFORE making any changes
        const currentState = getPodState(channel);
        const whitelistUsers = currentState.whitelist.filter(id => id !== oldOwnerId && id !== newOwnerId);
        const coOwnerUsers = currentState.coOwners.filter(id => id !== oldOwnerId && id !== newOwnerId);
        const isLocked = currentState.isLocked;
        const userLimit = currentState.limit;
        
        // Also check if old owner had Connect permission (they should, but preserve it explicitly)
        const oldOwnerOverwrite = channel.permissionOverwrites.cache.get(oldOwnerId);
        const oldOwnerHadConnect = oldOwnerOverwrite?.allow.has(PermissionFlagsBits.Connect) ?? false;

        logger.debug(`[Transfer] Preserving whitelist: ${whitelistUsers.length} users, co-owners: ${coOwnerUsers.length} users, locked: ${isLocked}, limit: ${userLimit}`);

        logger.debug(`[Transfer] Step 2: Updating database for ${channel.id}`);
        // Update database (keep originalOwnerId unchanged - creator can always reclaim)
        await dbLog.update('bytepods',
            () => db.update(bytepods)
                .set({
                    ownerId: newOwnerId,
                    ownerLeftAt: null,
                    reclaimRequestPending: false // Clear any pending reclaim requests
                })
                .where(eq(bytepods.channelId, channel.id)),
            { podId: channel.id, oldOwnerId, newOwnerId, operation: 'transferOwnership' }
        );

        logger.debug(`[Transfer] Step 3: Removing old owner management permissions`);
        // Remove ManageChannels and MoveMembers from old owner, but preserve Connect if they had it
        try {
            if (oldOwnerHadConnect) {
                // Preserve Connect permission for old owner (they stay whitelisted)
                await channel.permissionOverwrites.edit(oldOwnerId, {
                    Connect: true,
                    ManageChannels: null,
                    MoveMembers: null
                });
            } else {
                // Remove all permissions
                await channel.permissionOverwrites.edit(oldOwnerId, {
                    ManageChannels: null,
                    MoveMembers: null
                });
            }
        } catch (e) {
            // Old owner may have left the server entirely
            logger.debug(`[Transfer] Old owner permission edit failed: ${e.message}`);
        }

        logger.debug(`[Transfer] Step 4: Granting new owner permissions`);
        // Grant full permissions to new owner
        await channel.permissionOverwrites.edit(newOwnerId, {
            Connect: true,
            ManageChannels: true,
            MoveMembers: true
        });

        logger.debug(`[Transfer] Step 5: Preserving whitelist entries`);
        // Re-apply whitelist to ensure all whitelisted users retain access
        for (const userId of whitelistUsers) {
            try {
                await channel.permissionOverwrites.edit(userId, { Connect: true });
            } catch (e) {
                logger.warn(`[Transfer] Failed to preserve whitelist for ${userId}: ${e.message}`);
            }
        }

        logger.debug(`[Transfer] Step 6: Preserving co-owner entries`);
        // Re-apply co-owner permissions
        for (const userId of coOwnerUsers) {
            try {
                await channel.permissionOverwrites.edit(userId, {
                    Connect: true,
                    ManageChannels: true,
                    MoveMembers: true
                });
            } catch (e) {
                logger.warn(`[Transfer] Failed to preserve co-owner permissions for ${userId}: ${e.message}`);
            }
        }

        logger.debug(`[Transfer] Step 7: Preserving lock state and user limit`);
        // Preserve lock state (@everyone overwrite)
        try {
            await channel.permissionOverwrites.edit(guild.id, {
                Connect: isLocked ? false : null
            });
        } catch (e) {
            logger.warn(`[Transfer] Failed to preserve lock state: ${e.message}`);
        }

        // Preserve user limit
        try {
            await channel.setUserLimit(userLimit);
        } catch (e) {
            logger.warn(`[Transfer] Failed to preserve user limit: ${e.message}`);
        }

        logger.debug(`[Transfer] Step 8: Fetching new owner user`);
        // Notify the channel
        const newOwner = await client.users.fetch(newOwnerId).catch(() => null);
        const embed = embeds.info('Ownership Transferred',
            `<@${oldOwnerId}> left the channel. <@${newOwnerId}> is now the owner of this BytePod.`
        );

        logger.debug(`[Transfer] Step 9: Sending notification embed`);
        await channel.send({
            embeds: [embed],
            content: `<@${newOwnerId}>, you are now the owner! Run \`/pod panel\` to access controls.`
        });
        logger.info(`BytePod ownership transferred: ${channel.id} from ${oldOwnerId} to ${newOwnerId}`);
        logger.debug(`[Transfer] Complete!`);

    } catch (error) {
        logger.error(`[Transfer] ERROR at step: ${error.message}`);

        // Handle channel deletion race condition
        if (error.code === 10003) {
            logger.info(`Channel ${channel.id} was deleted during ownership transfer, skipping`);
            return;
        }

        logger.errorContext('Failed to transfer BytePod ownership', error, {
            channelId: channel.id,
            oldOwnerId,
            newOwnerId
        });
    }
}

module.exports = {
    name: Events.VoiceStateUpdate,
    async execute(oldState, newState) {
        const member = newState.member;
        const guild = newState.guild;

        if (member.user.bot) return;

        // DB Fetch
        const guildData = await dbLog.select('guilds',
            () => db.select().from(guilds).where(eq(guilds.id, guild.id)).get(),
            { guildId: guild.id }
        );
        if (!guildData || !guildData.voiceHubChannelId) {
            return;
        }

        const hubId = guildData.voiceHubChannelId;
        const joinedChannelId = newState.channelId;
        const leftChannelId = oldState.channelId;

        // Validate hub channel still exists (auto-clear stale config if manually deleted)
        const hubChannel = guild.channels.cache.get(hubId) || await guild.channels.fetch(hubId).catch(() => null);
        if (!hubChannel) {
            // Hub channel was deleted, clear the stale configuration
            logger.warn(`BytePod hub channel ${hubId} was deleted in guild ${guild.id}, auto-clearing configuration`);
            await dbLog.update('guilds',
                () => db.update(guilds)
                    .set({ voiceHubChannelId: null, voiceHubCategoryId: null })
                    .where(eq(guilds.id, guild.id)),
                { guildId: guild.id, operation: 'clearStaleHubConfig' }
            );
            return; // No hub to process
        }

        // --- JOIN HUB TRIGGER ---
        if (joinedChannelId === hubId) {
            const creationKey = `${guild.id}:${member.id}`;
            if (pendingPodCreations.has(creationKey)) {
                logger.debug(`Ignoring duplicate BytePod creation event for ${member.user.tag} in guild ${guild.id}`);
                return;
            }
            pendingPodCreations.add(creationKey);

            let newChannel = null;
            let userMoved = false;
            try {
                // Check Permissions
                const hasPerms = await checkBotPermissions(guild, member);
                if (!hasPerms) {
                    // Kick user from hub to prevent camping? Or just let them sit.
                    // Better to disconnect them so they know something failed if DM failed.
                    try { await member.voice.disconnect(); } catch (e) { }
                    return;
                }

                // Fetch User Settings
                const userSettings = await dbLog.select('bytepodUserSettings',
                    () => db.select().from(bytepodUserSettings).where(and(
                        eq(bytepodUserSettings.userId, member.id),
                        eq(bytepodUserSettings.guildId, guild.id)
                    )).get(),
                    { userId: member.id, guildId: guild.id }
                );
                const autoLock = userSettings?.autoLock || false;

                // Determine Category
                const categoryId = guildData.voiceHubCategoryId || newState.channel.parentId;

                // Late duplicate join-hub events can arrive after the user was moved
                // by an earlier create flow. Re-check before creating anything.
                const currentVoice = guild.voiceStates.cache.get(member.id);
                if (!currentVoice || currentVoice.channelId !== hubId) {
                    logger.debug(`BytePod creation skipped for ${member.user.tag}: no longer in hub before channel create`);
                    return;
                }

                const existingOwnedPod = await dbLog.select('bytepods',
                    () => db.select().from(bytepods).where(and(
                        eq(bytepods.ownerId, member.id),
                        eq(bytepods.guildId, guild.id)
                    )).get(),
                    { userId: member.id, guildId: guild.id, operation: 'existingOwnedPodCheck' }
                );

                if (existingOwnedPod) {
                    const existingChannel = guild.channels.cache.get(existingOwnedPod.channelId) ||
                        await guild.channels.fetch(existingOwnedPod.channelId).catch(() => null);

                    if (existingChannel) {
                        logger.info(`BytePod creation skipped for ${member.user.tag}: moving to existing pod ${existingOwnedPod.channelId}`);
                        await member.voice.setChannel(existingChannel);
                        userMoved = true;
                        return;
                    }

                    logger.info(`Cleaning up stale BytePod row ${existingOwnedPod.channelId} for ${member.user.tag} before creating a new pod`);
                    pendingOwnershipTransfers.delete(existingOwnedPod.channelId);
                    podStatsTracker.delete(existingOwnedPod.channelId);
                    await dbLog.delete('bytepodActiveSessions',
                        () => db.delete(bytepodActiveSessions).where(eq(bytepodActiveSessions.podId, existingOwnedPod.channelId)),
                        { podId: existingOwnedPod.channelId, operation: 'existingOwnedPodCleanup' }
                    );
                    await dbLog.delete('bytepods',
                        () => db.delete(bytepods).where(eq(bytepods.channelId, existingOwnedPod.channelId)),
                        { podId: existingOwnedPod.channelId, operation: 'existingOwnedPodCleanup' }
                    );
                }

                // Create Channel
                const nameStyle = userSettings?.podNameStyle || 'username';
                const channelName = (nameStyle === 'random'
                    ? getRandomPodName()
                    : `${member.user.username}'s Pod`).slice(0, 100);
                newChannel = await guild.channels.create({
                    name: channelName,
                    type: ChannelType.GuildVoice,
                    parent: categoryId,
                    permissionOverwrites: [
                        {
                            id: guild.id,
                            allow: [PermissionFlagsBits.ViewChannel],
                            deny: autoLock ? [PermissionFlagsBits.Connect] : [], // Apply Auto-Lock
                        },
                        {
                            id: member.id,
                            allow: [PermissionFlagsBits.Connect, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.MoveMembers],
                        }
                    ]
                });

                // Apply Auto-Whitelist Presets
                const presets = await dbLog.select('bytepodAutoWhitelist',
                    () => db.select().from(bytepodAutoWhitelist).where(and(
                        eq(bytepodAutoWhitelist.userId, member.id),
                        eq(bytepodAutoWhitelist.guildId, guild.id)
                    )),
                    { userId: member.id, guildId: guild.id }
                );
                for (const preset of presets) {
                    try {
                        const targetMember = await guild.members.fetch(preset.targetUserId).catch(() => null);
                        const targetUser = targetMember ? targetMember.user : await guild.client.users.fetch(preset.targetUserId).catch(() => null);

                        if (targetUser) {
                            await newChannel.permissionOverwrites.edit(targetUser, { Connect: true });
                        } else {
                            logger.warn(`Could not find user ${preset.targetUserId} for whitelist preset.`);
                        }
                    } catch (e) {
                        logger.error(`Failed to apply whitelist preset for ${preset.targetUserId}: ${e}`);
                    }
                }

                // Race guard: user may have left the hub during the async work above.
                // Calling setChannel() on a disconnected user throws DiscordAPIError[40032].
                // Voice state lives in guild.voiceStates.cache (kept fresh by gateway
                // VOICE_STATE_UPDATE events) — members.fetch() does NOT refresh it.
                // Note: if they moved to a different voice channel, setChannel() would
                // succeed, but we intentionally bail anyway — they chose to leave the hub.
                const freshVoice = guild.voiceStates.cache.get(member.id);
                if (!freshVoice || freshVoice.channelId !== hubId) {
                    logger.info(`BytePod creation aborted for ${member.user.tag}: left voice before move. Cleaning up orphan channel ${newChannel.id}`);
                    await newChannel.delete('BytePod creator disconnected before move').catch(() => {});
                    return;
                }

                // Move Member
                await member.voice.setChannel(newChannel);
                userMoved = true;

                // DB Insert - BytePod record
                await dbLog.insert('bytepods',
                    () => db.insert(bytepods).values({
                        channelId: newChannel.id,
                        guildId: guild.id,
                        ownerId: member.id,
                        originalOwnerId: member.id, // Track original creator for reclaim eligibility
                        createdAt: new Date(), // Explicit timestamp — schema default is evaluated once at load time
                    }),
                    { podId: newChannel.id, guildId: guild.id, userId: member.id }
                );

                // Track BytePod creation for achievements
                if (newState.client.activityStreakService) {
                    try {
                        await newState.client.activityStreakService.recordBytepodCreation(member.id, guild.id);
                    } catch (error) {
                        logger.debug('Failed to track BytePod creation:', error);
                    }
                }

                // Start voice session tracking (persisted to DB)
                await dbLog.insert('bytepodActiveSessions',
                    () => db.insert(bytepodActiveSessions).values({
                        podId: newChannel.id,
                        userId: member.id,
                        guildId: guild.id,
                        startTime: Date.now()
                    }),
                    { podId: newChannel.id, userId: member.id, guildId: guild.id }
                );

                // Initialize stats tracker for new pod
                podStatsTracker.set(newChannel.id, {
                    peakUsers: 1,
                    currentUsers: 1,
                    visitors: new Set([member.id]),
                    userDurations: new Map()  // accumulated per-user voice time (seconds)
                });

                // Send Welcome Message
                await newChannel.send({
                    embeds: [embeds.brand('Welcome to Your BytePod!', `Your personal voice channel has been created! 🎉\n\n**To manage your pod:** Run \`/pod panel\` to access controls (lock/unlock, whitelist, co-owners, etc.)`)],
                    content: `Welcome, ${member}!`
                });

            } catch (error) {
                // 40032: target user not connected to voice — they disconnected between
                // joining the hub and the bot's move attempt. Benign race, not a permission
                // problem; don't DM the user a misleading error. Just clean up the orphan.
                if (error.code === 40032) {
                    logger.info(`BytePod move aborted for ${member.user.tag}: user disconnected from voice before move (40032), channel ${newChannel?.id}`);
                    if (newChannel) {
                        await newChannel.delete('BytePod creator disconnected before move').catch(() => {});
                    }
                    return;
                }

                logger.error(`Failed to create BytePod for ${member.user.tag}: ${error}`);

                // Only clean up the channel if we never successfully moved the user into it.
                // If setChannel succeeded, the user is in the pod; deleting here would yank
                // them out with no explanation for a downstream DB/welcome-message failure.
                if (newChannel && !userMoved) {
                    await newChannel.delete('BytePod creation failed').catch(() => {});
                }

                // Alert User
                try {
                    await member.send({
                        embeds: [embeds.error('BytePod Creation Failed', `I couldn't create your pod or move you. Please ensure I have the **Administrator** or **Manage Channels** permission and that my role is **above** yours.\n\nError: \`${error.message}\``)]
                    });
                } catch (dmError) {
                    // DMs closed
                }

                // Don't attempt to disconnect a user who is already out of voice
                // (would just throw another 40032) or one who is successfully in the pod.
                if (!userMoved && member.voice.channelId) {
                    try { await member.voice.disconnect(); } catch (e) { }
                }
            } finally {
                pendingPodCreations.delete(creationKey);
            }
        }

        // --- JOIN POD TRIGGER (Existing BytePod) ---
        // Handle ownership return / reclaim when someone joins an existing pod
        // IMPORTANT: Only trigger if user actually moved channels (not just voice state change like mute/screenshare)
        if (joinedChannelId && joinedChannelId !== hubId && oldState.channelId !== newState.channelId) {
            // Track channel join for achievements
            if (newState.client.activityStreakService) {
                try {
                    await newState.client.activityStreakService.recordChannelJoin(member.id, member.guild.id);
                    await newState.client.activityStreakService.startVoiceSession(member.id, member.guild.id, joinedChannelId);
                } catch (error) {
                    logger.debug('Failed to track channel join:', error);
                }
            }

            const podData = await dbLog.select('bytepods',
                () => db.select().from(bytepods).where(eq(bytepods.channelId, joinedChannelId)).get(),
                { podId: joinedChannelId, guildId: guild.id }
            );

            if (podData) {
                logger.debug(`[Voice State] User ${member.id} joined BytePod ${joinedChannelId} (owner: ${podData.ownerId}, originalOwner: ${podData.originalOwnerId})`);
                const channel = newState.channel;

                // Case 1: Owner returned during grace period - cancel transfer
                if (podData.ownerId === member.id && podData.ownerLeftAt) {
                    logger.info(`BytePod owner ${member.id} returned to ${joinedChannelId}, cancelling ownership transfer`);

                    // Cancel pending timeout
                    if (pendingOwnershipTransfers.has(joinedChannelId)) {
                        clearTimeout(pendingOwnershipTransfers.get(joinedChannelId));
                        pendingOwnershipTransfers.delete(joinedChannelId);
                    }

                    // Clear ownerLeftAt in DB
                    await dbLog.update('bytepods',
                        () => db.update(bytepods)
                            .set({ ownerLeftAt: null })
                            .where(eq(bytepods.channelId, joinedChannelId)),
                        { podId: joinedChannelId, userId: member.id, operation: 'ownerReturned' }
                    );

                    // Notify channel
                    try {
                        await channel.send({
                            embeds: [embeds.success('Owner Returned', `<@${member.id}> has returned. Ownership transfer cancelled.`)]
                        });
                    } catch (e) { }
                }

                // Case 2: Original owner rejoins AFTER ownership was transferred
                // (They are originalOwnerId but NOT ownerId, and transfer already happened)
                else if (
                    podData.originalOwnerId === member.id &&
                    podData.ownerId !== member.id &&
                    !podData.ownerLeftAt && // Transfer already completed (not in grace period)
                    !podData.reclaimRequestPending // No pending request already
                ) {
                    // Send reclaim prompt in channel
                    const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

                    const reclaimRow = new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setCustomId(`bytepod_reclaim_request_${joinedChannelId}_${member.id}`)
                            .setLabel('Request Ownership Back')
                            .setStyle(ButtonStyle.Primary)
                            .setEmoji('👑')
                    );

                    try {
                        await channel.send({
                            content: `<@${member.id}>`,
                            embeds: [embeds.info('Welcome Back!', `You originally created this BytePod. Would you like to request ownership back from <@${podData.ownerId}>?`)],
                            components: [reclaimRow]
                        });

                        // Mark request as pending to prevent duplicate prompts
                        await dbLog.update('bytepods',
                            () => db.update(bytepods)
                                .set({ reclaimRequestPending: true })
                                .where(eq(bytepods.channelId, joinedChannelId)),
                            { podId: joinedChannelId, userId: member.id, operation: 'reclaimRequest' }
                        );

                        logger.info(`Sent ownership reclaim prompt to ${member.id} for pod ${joinedChannelId}`);
                    } catch (e) {
                        logger.error(`Failed to send reclaim prompt: ${e.message}`);
                    }
                }
                // Case 3: Backfill originalOwnerId for old pods that don't have it set
                else if (!podData.originalOwnerId && podData.ownerId === member.id) {
                    // Current owner joining their own pod but originalOwnerId is null - backfill it
                    await dbLog.update('bytepods',
                        () => db.update(bytepods)
                            .set({ originalOwnerId: member.id })
                            .where(eq(bytepods.channelId, joinedChannelId)),
                        { podId: joinedChannelId, userId: member.id, operation: 'backfillOriginalOwner' }
                    );
                    logger.info(`Backfilled originalOwnerId for pod ${joinedChannelId}`);
                }

                // Start voice session for this user
                const existingSession = await dbLog.select('bytepodActiveSessions',
                    () => db.select().from(bytepodActiveSessions)
                        .where(and(
                            eq(bytepodActiveSessions.podId, joinedChannelId),
                            eq(bytepodActiveSessions.userId, member.id)
                        )).get(),
                    { podId: joinedChannelId, userId: member.id }
                );

                if (!existingSession) {
                    await dbLog.insert('bytepodActiveSessions',
                        () => db.insert(bytepodActiveSessions).values({
                            podId: joinedChannelId,
                            userId: member.id,
                            guildId: guild.id,
                            startTime: Date.now()
                        }),
                        { podId: joinedChannelId, userId: member.id, guildId: guild.id }
                    );
                }

                // Update stats tracker
                let stats = podStatsTracker.get(joinedChannelId);
                if (!stats) {
                    // Reconstruct from channel state (bot restart case)
                    stats = {
                        peakUsers: channel.members.size,
                        currentUsers: channel.members.size,
                        visitors: new Set(Array.from(channel.members.keys()).filter(id => {
                            const m = channel.members.get(id);
                            return m && !m.user.bot;
                        })),
                        userDurations: new Map()  // can't recover past durations after restart
                    };
                    podStatsTracker.set(joinedChannelId, stats);
                } else {
                    stats.currentUsers++;
                    if (stats.currentUsers > stats.peakUsers) {
                        stats.peakUsers = stats.currentUsers;
                    }
                    if (!member.user.bot) {
                        stats.visitors.add(member.id);
                    }
                }
            }
        }

        // --- LEAVE POD TRIGGER ---
        // IMPORTANT: Only trigger if user actually moved channels (not just voice state change like mute/screenshare)
        if (leftChannelId && leftChannelId !== hubId && oldState.channelId !== newState.channelId) {
            logger.debug(`[Voice State] User ${member.id} left channel ${leftChannelId} (joined: ${joinedChannelId || 'none'})`);

            // Track voice session end for achievements
            if (newState.client.activityStreakService) {
                try {
                    await newState.client.activityStreakService.endVoiceSession(member.id, member.guild.id, leftChannelId);
                } catch (error) {
                    logger.debug('Failed to track voice session end:', error);
                }
            }

            // Finalize voice session for the leaving user
            const session = await dbLog.select('bytepodActiveSessions',
                () => db.select().from(bytepodActiveSessions)
                    .where(and(
                        eq(bytepodActiveSessions.podId, leftChannelId),
                        eq(bytepodActiveSessions.userId, member.id)
                    )).get(),
                { podId: leftChannelId, userId: member.id }
            );

            // Capture leaving user's duration BEFORE finalizing (which deletes the session).
            // This is needed so their time is included in the pod summary if the pod becomes empty.
            const leavingUserDuration = session
                ? { userId: session.userId, durationSeconds: Math.floor((Date.now() - session.startTime) / 1000) }
                : null;

            if (session) {
                try {
                    await finalizeVoiceSession(session, newState.client);
                } catch (e) {
                    logger.error(`Failed to finalize voice session: ${e}`);
                }
            }

            // Decrement stats tracker and accumulate this user's duration
            const leaveStats = podStatsTracker.get(leftChannelId);
            if (leaveStats) {
                leaveStats.currentUsers = Math.max(0, leaveStats.currentUsers - 1);
                if (leavingUserDuration) {
                    const prev = leaveStats.userDurations.get(leavingUserDuration.userId) || 0;
                    leaveStats.userDurations.set(leavingUserDuration.userId, prev + leavingUserDuration.durationSeconds);
                }
            }

            // Check if it's a BytePod
            const podData = await dbLog.select('bytepods',
                () => db.select().from(bytepods).where(eq(bytepods.channelId, leftChannelId)).get(),
                { podId: leftChannelId, guildId: guild.id }
            );

            if (podData) {
                const channel = oldState.channel || await guild.channels.fetch(leftChannelId).catch(() => null);

                // --- CHANNEL ALREADY DELETED: CLEANUP DB IMMEDIATELY ---
                if (!channel) {
                    logger.info(`BytePod channel ${leftChannelId} was manually deleted, cleaning up database`);

                    // Cancel any pending ownership transfer
                    if (pendingOwnershipTransfers.has(leftChannelId)) {
                        clearTimeout(pendingOwnershipTransfers.get(leftChannelId));
                        pendingOwnershipTransfers.delete(leftChannelId);
                    }

                    // Clean up stats tracker
                    podStatsTracker.delete(leftChannelId);

                    // Finalize any remaining sessions and clean up
                    const remainingSessions = await dbLog.select('bytepodActiveSessions',
                        () => db.select().from(bytepodActiveSessions)
                            .where(eq(bytepodActiveSessions.podId, leftChannelId)),
                        { podId: leftChannelId, operation: 'orphanCleanup' }
                    );
                    for (const s of remainingSessions) {
                        await finalizeVoiceSession(s, newState.client);
                    }

                    // Delete orphaned pod record
                    await dbLog.delete('bytepods',
                        () => db.delete(bytepods).where(eq(bytepods.channelId, leftChannelId)),
                        { podId: leftChannelId, guildId: guild.id, operation: 'orphanedChannelCleanup' }
                    );
                } else if (channel.members.size === 0) {
                    // --- CHANNEL EMPTY: DELETE POD ---
                    // Cancel any pending ownership transfer
                    if (pendingOwnershipTransfers.has(leftChannelId)) {
                        clearTimeout(pendingOwnershipTransfers.get(leftChannelId));
                        pendingOwnershipTransfers.delete(leftChannelId);
                    }

                    // --- GENERATE SESSION SUMMARY ---
                    try {
                        // Get all sessions for this pod
                        const sessions = await dbLog.select('bytepodActiveSessions',
                            () => db.select().from(bytepodActiveSessions)
                                .where(eq(bytepodActiveSessions.podId, leftChannelId)),
                            { podId: leftChannelId }
                        );

                        // Get stats from tracker or reconstruct
                        let stats = podStatsTracker.get(leftChannelId);
                        if (!stats) {
                            // Bot restart fallback: can't recover past durations, use active sessions for what's left
                            const activeDurations = new Map();
                            const visitorIds = new Set();
                            for (const s of sessions) {
                                const d = Math.floor((Date.now() - s.startTime) / 1000);
                                activeDurations.set(s.userId, (activeDurations.get(s.userId) || 0) + d);
                                visitorIds.add(s.userId);
                            }
                            if (leavingUserDuration) {
                                activeDurations.set(
                                    leavingUserDuration.userId,
                                    (activeDurations.get(leavingUserDuration.userId) || 0) + leavingUserDuration.durationSeconds
                                );
                                visitorIds.add(leavingUserDuration.userId);
                            }
                            stats = {
                                peakUsers: visitorIds.size || 1,
                                currentUsers: sessions.length || 0,
                                visitors: visitorIds,
                                userDurations: activeDurations
                            };
                        }

                        // Use durations accumulated in podStatsTracker as users left throughout the session.
                        // sessions[] is empty here because each user's row is deleted from bytepodActiveSessions
                        // when they leave — so we can't recalculate from DB at this point.
                        const userDurations = new Map(stats.userDurations || []);

                        // Build summary data
                        const summaryData = {
                            podName: channel.name,
                            ownerId: podData.ownerId,
                            guildId: guild.id,
                            startedAt: podData.createdAt,
                            endedAt: new Date(),
                            peakUsers: stats.peakUsers,
                            uniqueVisitors: stats.visitors.size,
                            userDurations: Array.from(userDurations.entries())
                                .map(([userId, durationSeconds]) => ({ userId, durationSeconds }))
                        };

                        // Check if owner wants summaries (default: off)
                        const ownerSettings = await dbLog.select('bytepodUserSettings',
                            () => db.select().from(bytepodUserSettings)
                                .where(and(
                                    eq(bytepodUserSettings.userId, podData.ownerId),
                                    eq(bytepodUserSettings.guildId, guild.id)
                                )).get(),
                            { userId: podData.ownerId, guildId: guild.id }
                        );

                        // Only DM if explicitly enabled
                        if (ownerSettings?.summaryEnabled) {
                            const owner = await newState.client.users.fetch(podData.ownerId).catch(() => null);
                            if (owner) {
                                const summaryEmbed = createSummaryEmbed(summaryData);
                                await owner.send({ embeds: [summaryEmbed] }).catch(() => {
                                    logger.debug(`Could not DM BytePod summary to ${podData.ownerId}`);
                                });
                            }
                        }

                        // Archive to history table
                        const totalSeconds = [...userDurations.values()].reduce((a, b) => a + b, 0);
                        await dbLog.insert('bytepodSessionHistory',
                            () => db.insert(bytepodSessionHistory).values({
                                podId: leftChannelId,
                                guildId: guild.id,
                                ownerId: podData.ownerId,
                                podName: summaryData.podName,
                                startedAt: summaryData.startedAt,
                                endedAt: summaryData.endedAt,
                                peakUsers: summaryData.peakUsers,
                                uniqueVisitors: summaryData.uniqueVisitors,
                                totalVoiceMinutes: Math.floor(totalSeconds / 60),
                                visitorData: JSON.stringify(summaryData.userDurations)
                            }),
                            { podId: leftChannelId, guildId: guild.id }
                        );

                        // Clean up tracker
                        podStatsTracker.delete(leftChannelId);

                    } catch (error) {
                        logger.error(`Failed to generate BytePod summary:`, error);
                        // Continue with deletion regardless
                    }

                    try {
                        // Finalize any remaining sessions
                        const remainingSessions = await dbLog.select('bytepodActiveSessions',
                            () => db.select().from(bytepodActiveSessions)
                                .where(eq(bytepodActiveSessions.podId, leftChannelId)),
                            { podId: leftChannelId, operation: 'finalCleanup' }
                        );
                        for (const s of remainingSessions) {
                            await finalizeVoiceSession(s, newState.client);
                        }

                        // Delete channel and pod record
                        await channel.delete();
                        await dbLog.delete('bytepods',
                            () => db.delete(bytepods).where(eq(bytepods.channelId, leftChannelId)),
                            { podId: leftChannelId, guildId: guild.id, operation: 'deletePod' }
                        );
                    } catch (error) {
                        // 10003: channel was already deleted (manually, or by a racing cleanup).
                        // Benign — just reconcile the DB. Don't log at error level.
                        if (error.code === 10003) {
                            logger.info(`BytePod ${leftChannelId} already deleted during cleanup, reconciling DB`);
                            await dbLog.delete('bytepods',
                                () => db.delete(bytepods).where(eq(bytepods.channelId, leftChannelId)),
                                { podId: leftChannelId, operation: 'cleanupError' }
                            );
                            await dbLog.delete('bytepodActiveSessions',
                                () => db.delete(bytepodActiveSessions).where(eq(bytepodActiveSessions.podId, leftChannelId)),
                                { podId: leftChannelId, operation: 'cleanupError' }
                            );
                        } else {
                            logger.error(`Failed to cleanup BytePod ${leftChannelId}: ${error}`);
                        }
                    }
                } else if (channel && channel.members.size > 0 && podData.ownerId === member.id) {
                    // --- OWNER LEFT BUT OTHERS REMAIN: SCHEDULE TRANSFER ---

                    // Defensive check: Verify owner is actually absent (Discord sometimes sends false leave events)
                    const freshChannel = await guild.channels.fetch(leftChannelId).catch(() => null);
                    if (!freshChannel) {
                        logger.debug(`Channel ${leftChannelId} no longer exists, skipping transfer logic`);
                        return;
                    }

                    if (freshChannel.members.has(member.id)) {
                        logger.warn(`[FALSE LEAVE] Owner ${member.id} appears to still be in channel ${leftChannelId} despite leave event. Skipping transfer.`);
                        logger.debug(`[FALSE LEAVE] Channel members: ${Array.from(freshChannel.members.keys()).join(', ')}`);
                        return;
                    }

                    logger.info(`BytePod owner ${member.id} left channel ${leftChannelId} (verified absent), scheduling ownership transfer in 5 minutes`);
                    logger.debug(`Remaining members: ${Array.from(freshChannel.members.keys()).join(', ')}`);

                    // Mark owner as left in DB
                    await dbLog.update('bytepods',
                        () => db.update(bytepods)
                            .set({ ownerLeftAt: Date.now() })
                            .where(eq(bytepods.channelId, leftChannelId)),
                        { podId: leftChannelId, userId: member.id, operation: 'ownerLeft' }
                    );

                    // Schedule transfer after 5 minutes
                    const timeoutId = setTimeout(async () => {
                        pendingOwnershipTransfers.delete(leftChannelId);

                        try {
                            logger.debug(`[Transfer Timeout] Checking pod ${leftChannelId} for transfer`);

                            // Re-fetch pod data and channel state
                            const currentPodData = await dbLog.select('bytepods',
                                () => db.select().from(bytepods).where(eq(bytepods.channelId, leftChannelId)).get(),
                                { podId: leftChannelId, operation: 'transferTimeoutCheck' }
                            );
                            if (!currentPodData || !currentPodData.ownerLeftAt) {
                                logger.debug(`[Transfer Timeout] Skipping - pod deleted or owner returned (ownerLeftAt: ${currentPodData?.ownerLeftAt})`);
                                return;
                            }

                            const currentChannel = await guild.channels.fetch(leftChannelId).catch(() => null);
                            if (!currentChannel || currentChannel.members.size === 0) {
                                logger.debug(`[Transfer Timeout] Skipping - channel deleted or empty (exists: ${!!currentChannel}, members: ${currentChannel?.members.size || 0})`);
                                return; // Channel deleted or empty
                            }

                            // Defensive check: Verify owner is still absent before transferring
                            if (currentChannel.members.has(currentPodData.ownerId)) {
                                logger.warn(`[Transfer Timeout] Owner ${currentPodData.ownerId} is back in channel ${leftChannelId}, cancelling transfer`);
                                logger.debug(`[Transfer Timeout] Channel members: ${Array.from(currentChannel.members.keys()).join(', ')}`);
                                // Clear ownerLeftAt since they're back
                                await dbLog.update('bytepods',
                                    () => db.update(bytepods)
                                        .set({ ownerLeftAt: null })
                                        .where(eq(bytepods.channelId, leftChannelId)),
                                    { podId: leftChannelId, operation: 'cancelTransferOwnerReturned' }
                                );
                                return;
                            }

                            // Pick the first member in the channel as new owner
                            const newOwner = currentChannel.members.first();
                            if (newOwner && !newOwner.user.bot) {
                                logger.debug(`[Transfer Timeout] Transferring ownership to ${newOwner.id}`);
                                await transferOwnership(currentChannel, currentPodData, newOwner.id, guild.client);
                            } else {
                                // No eligible members found (only old owner or bots remain)
                                // Clear the ownerLeftAt since owner is still the only eligible person
                                await dbLog.update('bytepods',
                                    () => db.update(bytepods)
                                        .set({ ownerLeftAt: null })
                                        .where(eq(bytepods.channelId, leftChannelId)),
                                    { podId: leftChannelId, operation: 'cancelTransferNoEligibleOwner' }
                                );
                                logger.debug(`[Transfer Timeout] No eligible new owner found - only old owner or bots remain`);
                            }
                        } catch (error) {
                            logger.errorContext('Ownership transfer timeout failed', error, {
                                channelId: leftChannelId
                            });
                        }
                    }, OWNERSHIP_TRANSFER_DELAY_MS);

                    pendingOwnershipTransfers.set(leftChannelId, timeoutId);
                }
            }
        }
    }
};
