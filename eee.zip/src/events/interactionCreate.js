const { Events, Collection, PermissionFlagsBits, MessageFlags } = require('discord.js');
const logger = require('../utils/logger');
const embeds = require('../utils/embeds');
const config = require('../utils/config');
const { db } = require('../database/index');
const { users, commandPermissions, customAchievements } = require('../database/schema');
const { sql, eq, and } = require('drizzle-orm');
const { dbLog } = require('../utils/dbLogger');

// Track processed interactions to prevent duplicates
const processedInteractions = new Set();
const cleanupInterval = setInterval(() => {
    processedInteractions.clear(); // Clear every minute to prevent memory leak
}, 60000);
// Allow Jest to exit cleanly
if (cleanupInterval.unref) cleanupInterval.unref();

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction, client) {
        // Prevent duplicate processing of the same interaction
        if (processedInteractions.has(interaction.id)) {
            logger.debug(`Skipping duplicate interaction: ${interaction.id}`);
            return;
        }
        processedInteractions.add(interaction.id);
        // Handle Autocomplete interactions
        if (interaction.isAutocomplete()) {
            const command = client.commands.get(interaction.commandName);
            if (!command) return;

            try {
                await command.autocomplete(interaction, client);
            } catch (error) {
                logger.error(`Autocomplete Error: ${error}`);
            }
            return;
        }

        // Handle BytePod Interactions
        if ((interaction.isButton() || interaction.isAnySelectMenu() || interaction.isModalSubmit()) && interaction.customId.startsWith('bytepod_')) {
            const command = client.commands.get('bytepod');
            if (command && command.handleInteraction) {
                try {
                    await command.handleInteraction(interaction, client);
                } catch (error) {
                    logger.errorContext('BytePod Interaction Error', error, {
                        customId: interaction.customId,
                        channelId: interaction.channelId,
                        userId: interaction.user?.id,
                        guildId: interaction.guildId
                    });
                    // Attempt to notify user if possible
                    try {
                        const errorEmbed = embeds.error('Interaction Failed', 'An error occurred while processing this action. The channel may have been deleted or the bot lacks permissions.');
                        if (interaction.replied || interaction.deferred) {
                            await interaction.followUp({ embeds: [errorEmbed], flags: [MessageFlags.Ephemeral] });
                        } else {
                            await interaction.reply({ embeds: [errorEmbed], flags: [MessageFlags.Ephemeral] });
                        }
                    } catch (e) {
                        logger.error('Failed to send error response to user:', e);
                    }
                }
            }
            return;
        }

        // Handle Bookmark Interactions
        if ((interaction.isButton()) && interaction.customId.startsWith('bookmark_')) {
            const command = client.commands.get('bookmark');
            if (command && command.handleInteraction) {
                try {
                    await command.handleInteraction(interaction, client);
                } catch (error) {
                    logger.errorContext('Bookmark Interaction Error', error, {
                        customId: interaction.customId,
                        userId: interaction.user?.id,
                        guildId: interaction.guildId
                    });
                    // Attempt to notify user if possible
                    try {
                        const errorEmbed = embeds.error('Interaction Failed', 'An error occurred while processing this action.');
                        if (interaction.replied || interaction.deferred) {
                            await interaction.followUp({ embeds: [errorEmbed], flags: [MessageFlags.Ephemeral] });
                        } else {
                            await interaction.reply({ embeds: [errorEmbed], flags: [MessageFlags.Ephemeral] });
                        }
                    } catch (e) {
                        logger.error('Failed to send error response to user:', e);
                    }
                }
            }
            return;
        }

        // Handle Help Button Interactions
        if ((interaction.isButton()) && interaction.customId.startsWith('help_page_')) {
            const command = client.commands.get('help');
            if (command && command.handleInteraction) {
                try {
                    await command.handleInteraction(interaction, client);
                } catch (error) {
                    logger.errorContext('Help Interaction Error', error, {
                        customId: interaction.customId,
                        userId: interaction.user?.id,
                        guildId: interaction.guildId
                    });
                    // Attempt to notify user if possible
                    try {
                        const errorEmbed = embeds.error('Interaction Failed', 'An error occurred while loading this page.');
                        if (interaction.replied || interaction.deferred) {
                            await interaction.followUp({ embeds: [errorEmbed], flags: [MessageFlags.Ephemeral] });
                        } else {
                            await interaction.reply({ embeds: [errorEmbed], flags: [MessageFlags.Ephemeral] });
                        }
                    } catch (e) {
                        logger.error('Failed to send error response to user:', e);
                    }
                }
            }
            return;
        }

        // Handle Moderation Button Interactions
        if (interaction.isButton() && interaction.customId.startsWith('mod_')) {
            const modActionsMenu = client.contextMenus.get('Moderate User');
            if (modActionsMenu && modActionsMenu.handleButton) {
                try {
                    await modActionsMenu.handleButton(interaction, client);
                } catch (error) {
                    logger.errorContext('Moderation Button Error', error, {
                        customId: interaction.customId,
                        userId: interaction.user?.id,
                        guildId: interaction.guildId
                    });
                    // Attempt to notify user if possible
                    try {
                        const errorEmbed = embeds.error('Interaction Failed', 'An error occurred while processing this moderation action.');
                        if (interaction.replied || interaction.deferred) {
                            await interaction.followUp({ embeds: [errorEmbed], flags: [MessageFlags.Ephemeral] });
                        } else {
                            await interaction.reply({ embeds: [errorEmbed], flags: [MessageFlags.Ephemeral] });
                        }
                    } catch (e) {
                        logger.error('Failed to send error response to user:', e);
                    }
                }
            }
            return;
        }

        // Handle Achievement Creation Modal Submission
        if (interaction.isModalSubmit() && interaction.customId === 'achievement_create_modal') {
            try {
                const { db } = require('../database');
                const { customAchievements } = require('../database/schema');
                const { and, eq } = require('drizzle-orm');

                await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

                // Extract field values
                const title = interaction.fields.getTextInputValue('achievement_title').trim();
                const description = interaction.fields.getTextInputValue('achievement_description').trim();
                const emoji = interaction.fields.getTextInputValue('achievement_emoji').trim();
                const rarity = interaction.fields.getTextInputValue('achievement_rarity').trim().toLowerCase();
                const pointsStr = interaction.fields.getTextInputValue('achievement_points').trim();

                // Validate rarity
                const validRarities = ['common', 'uncommon', 'rare', 'epic', 'legendary', 'mythic'];
                if (!validRarities.includes(rarity)) {
                    return interaction.editReply({
                        embeds: [embeds.error(
                            'Invalid Rarity',
                            `Rarity must be one of: ${validRarities.join(', ')}\n\nYou entered: **${rarity}**`
                        )]
                    });
                }

                // Validate points
                const points = parseInt(pointsStr);
                if (isNaN(points) || points < 1 || points > 1000) {
                    return interaction.editReply({
                        embeds: [embeds.error('Invalid Points', 'Points must be a number between 1 and 1000.')]
                    });
                }

                // Generate achievement ID from title
                const achievementId = `custom_${interaction.guild.id}_${title.toLowerCase().replace(/[^a-z0-9]/g, '_').substring(0, 50)}`;

                // Check if achievement with this ID already exists
                const existing = await dbLog.select('customAchievements',
                    () => db.select()
                        .from(customAchievements)
                        .where(and(
                            eq(customAchievements.guildId, interaction.guild.id),
                            eq(customAchievements.achievementId, achievementId)
                        ))
                        .get(),
                    { guildId: interaction.guild.id, achievementId }
                );

                if (existing) {
                    return interaction.editReply({
                        embeds: [embeds.error(
                            'Already Exists',
                            `An achievement with a similar title already exists.\n\n**ID:** \`${achievementId}\`\n\nPlease use a different title.`
                        )]
                    });
                }

                // Create the custom achievement
                await dbLog.insert('customAchievements',
                    () => db.insert(customAchievements).values({
                        guildId: interaction.guild.id,
                        achievementId,
                        title,
                        description,
                        emoji,
                        category: 'special',  // Custom achievements are in special category
                        rarity,
                        points,
                        criteria: JSON.stringify({ type: 'manual' }),  // Manual-only by default
                        grantRole: false,  // No role by default
                        enabled: true,
                        createdBy: interaction.user.id,
                        createdAt: new Date()
                    }),
                    { guildId: interaction.guild.id, achievementId, createdBy: interaction.user.id }
                );

                // Invalidate achievement cache
                if (client.activityStreakService) {
                    client.activityStreakService.achievementManager.invalidateCache();
                }

                const embed = embeds.success(
                    '✨ Custom Achievement Created!',
                    `**${emoji} ${title}** has been created for this server!`
                );

                embed.addFields(
                    { name: 'ID', value: `\`${achievementId}\``, inline: false },
                    { name: 'Description', value: description, inline: false },
                    { name: 'Rarity', value: rarity, inline: true },
                    { name: 'Points', value: `${points}`, inline: true },
                    { name: 'Award Method', value: 'Manual only', inline: true }
                );

                embed.setFooter({ text: 'Use /achievement award to give this achievement to users' });

                await interaction.editReply({ embeds: [embed] });

                logger.success(`Custom achievement "${title}" created in ${interaction.guild.name} by ${interaction.user.tag}`);

            } catch (error) {
                logger.error('Error creating custom achievement:', error);
                const errorEmbed = embeds.error('Creation Failed', 'An error occurred while creating the achievement.');
                if (interaction.deferred || interaction.replied) {
                    await interaction.editReply({ embeds: [errorEmbed] });
                } else {
                    await interaction.reply({ embeds: [errorEmbed], flags: [MessageFlags.Ephemeral] });
                }
            }
            return;
        }

        // Handle Moderation Modal Submissions
        if (interaction.isModalSubmit() && interaction.customId.startsWith('modal_')) {
            const modActionsMenu = client.contextMenus.get('Moderate User');
            if (modActionsMenu && modActionsMenu.handleModal) {
                try {
                    await modActionsMenu.handleModal(interaction, client);
                } catch (error) {
                    logger.errorContext('Moderation Modal Error', error, {
                        customId: interaction.customId,
                        userId: interaction.user?.id,
                        guildId: interaction.guildId
                    });
                    // Attempt to notify user if possible
                    try {
                        const errorEmbed = embeds.error('Action Failed', 'An error occurred while processing this moderation action.');
                        if (interaction.replied || interaction.deferred) {
                            await interaction.followUp({ embeds: [errorEmbed], flags: [MessageFlags.Ephemeral] });
                        } else {
                            await interaction.reply({ embeds: [errorEmbed], flags: [MessageFlags.Ephemeral] });
                        }
                    } catch (e) {
                        logger.error('Failed to send error response to user:', e);
                    }
                }
            }
            return;
        }

        // Handle Context Menu Commands (User & Message)
        if (interaction.isUserContextMenuCommand() || interaction.isMessageContextMenuCommand()) {
            const menu = client.contextMenus.get(interaction.commandName);

            if (!menu) {
                logger.error(`No context menu matching ${interaction.commandName} was found.`);
                return;
            }

            // Same security pipeline as slash commands

            // 1. DM Check
            const isDM = !interaction.guild;
            const dmAllowed = menu.data.dm_permission !== false;

            if (isDM && !dmAllowed) {
                return interaction.reply({
                    embeds: [embeds.error('Server Only', 'This action can only be used within a server.')],
                    flags: [MessageFlags.Ephemeral]
                });
            }

            // 2. Permission checks (if in guild)
            if (interaction.guild && menu.permissions) {
                const { checkUserPermissions } = require('../utils/permissions');
                const { allowed, error } = await checkUserPermissions(interaction, menu);

                if (!allowed) {
                    return interaction.reply({
                        embeds: [error],
                        flags: [MessageFlags.Ephemeral]
                    });
                }
            }

            // 3. Cooldown (if defined)
            if (menu.cooldown) {
                const { cooldowns } = client;
                if (!cooldowns.has(menu.data.name)) {
                    cooldowns.set(menu.data.name, new Collection());
                }

                const now = Date.now();
                const timestamps = cooldowns.get(menu.data.name);
                const cooldownAmount = menu.cooldown * 1000;

                if (timestamps.has(interaction.user.id)) {
                    const expirationTime = timestamps.get(interaction.user.id) + cooldownAmount;

                    if (now < expirationTime) {
                        const expiredTimestamp = Math.round(expirationTime / 1000);
                        return interaction.reply({
                            embeds: [embeds.warn('Cooldown Active', `Please wait, you can use this again <t:${expiredTimestamp}:R>.`)],
                            flags: [MessageFlags.Ephemeral]
                        });
                    }
                }

                timestamps.set(interaction.user.id, now);
                setTimeout(() => timestamps.delete(interaction.user.id), cooldownAmount);
            }

            // 4. Auto-defer if long-running
            if (menu.longRunning) {
                await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
            }

            // 5. Execute
            try {
                await menu.execute(interaction, client);

                // Track context menu usage for achievements
                if (client.activityStreakService && interaction.guild) {
                    try {
                        await client.activityStreakService.recordActivity(
                            interaction.user.id,
                            interaction.guild.id,
                            'command',
                            1
                        );

                        // Track unique command usage for Command Explorer achievement
                        await client.activityStreakService.recordCommandUsage(
                            interaction.user.id,
                            interaction.guild.id,
                            interaction.commandName
                        );
                    } catch (trackError) {
                        logger.debug('Activity streak tracking error:', trackError);
                    }
                }
            } catch (error) {
                logger.errorContext(`Error executing context menu: ${interaction.commandName}`, error, {
                    menuName: interaction.commandName,
                    userId: interaction.user.id,
                    guildId: interaction.guildId,
                    targetType: interaction.targetType
                });

                const errorMessage = embeds.error('Error', 'An unexpected error occurred while processing this action.');

                try {
                    if (interaction.replied || interaction.deferred) {
                        await interaction.followUp({ embeds: [errorMessage], flags: [MessageFlags.Ephemeral] });
                    } else {
                        await interaction.reply({ embeds: [errorMessage], flags: [MessageFlags.Ephemeral] });
                    }
                } catch (replyError) {
                    // Interaction expired or already handled - log but don't crash
                    logger.debug(`Could not send error response: ${replyError.message}`);
                }
            }

            return;
        }

        if (!interaction.isChatInputCommand()) return;

        const command = client.commands.get(interaction.commandName);

        if (!command) {
            logger.error(`No command matching ${interaction.commandName} was found.`);
            return;
        }

        // --- SECURITY & EDGE CASES ---

        // 1. Guild Only Restriction (Check data.dm_permission if undefined, default to true for slash commands)
        const isDM = !interaction.guild;
        const dmAllowed = command.data.dm_permission !== false;

        if (isDM && !dmAllowed) {
            return interaction.reply({
                embeds: [embeds.error('Guild Only', 'This command can only be used within a server.')],
                flags: [MessageFlags.Ephemeral]
            });
        }

        // 2. Bot Permission Verification (Only if in a guild)
        if (interaction.guild) {
            const botMember = interaction.guild.members.me;
            if (!botMember.permissionsIn(interaction.channel).has([PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks])) {
                try {
                    return await interaction.reply({
                        content: '❌ I do not have permission to send embeds in this channel. Please ensure I have "Send Messages" and "Embed Links" permissions.',
                        flags: [MessageFlags.Ephemeral]
                    });
                } catch (e) {
                    logger.error(`Failed to notify about missing permissions in ${interaction.guild.id}: ${e}`);
                    return;
                }
            }
        }

        // 3. Developer Only Check
        if (command.devOnly && !config.developers.includes(interaction.user.id)) {
            return interaction.reply({
                embeds: [embeds.error('Access Denied', 'This command is restricted to bot developers.')],
                flags: [MessageFlags.Ephemeral]
            });
        }

        // 4. Permission Checks (Modular)
        if (interaction.guild) {
            const { checkUserPermissions } = require('../utils/permissions');
            const { allowed, error } = await checkUserPermissions(interaction, command);

            if (!allowed) {
                return interaction.reply({
                    embeds: [error],
                    flags: [MessageFlags.Ephemeral]
                });
            }
        }

        // 5. Cooldown Logic
        const { cooldowns } = client;
        if (!cooldowns.has(command.data.name)) {
            cooldowns.set(command.data.name, new Collection());
        }

        const now = Date.now();
        const timestamps = cooldowns.get(command.data.name);
        const defaultCooldownDuration = 3;
        const cooldownAmount = (command.cooldown ?? defaultCooldownDuration) * 1000;

        if (timestamps.has(interaction.user.id)) {
            const expirationTime = timestamps.get(interaction.user.id) + cooldownAmount;

            if (now < expirationTime) {
                const expiredTimestamp = Math.round(expirationTime / 1000);
                return interaction.reply({
                    embeds: [embeds.warn('Cooldown Active', `Please wait, you can use this command again <t:${expiredTimestamp}:R>.`)],
                    flags: [MessageFlags.Ephemeral]
                });
            }
        }

        // --- AUTHORIZED EXECUTION START ---

        // 5a. Interaction Deferral
        // Defer before non-critical writes so slow SQLite/disk I/O cannot expire
        // the Discord interaction token for long-running commands.
        if (command.longRunning) {
            await interaction.deferReply({ flags: (command.deferEphemeral || command.devOnly) ? [MessageFlags.Ephemeral] : [] });
        }

        // Update database tracking
        try {
            await dbLog.insert('users',
                () => db.insert(users).values({
                    id: interaction.user.id,
                    guildId: interaction.guild?.id ?? 'DM',
                    commandsRun: 1,
                    lastSeen: new Date(),
                }).onConflictDoUpdate({
                    target: users.id,
                    set: {
                        commandsRun: sql`${users.commandsRun} + 1`,
                        lastSeen: new Date(),
                    },
                }),
                { userId: interaction.user.id, commandName: command.data.name }
            );
        } catch (error) {
            logger.error(`Failed to update user stats: ${error}`);
        }

        timestamps.set(interaction.user.id, now);
        setTimeout(() => timestamps.delete(interaction.user.id), cooldownAmount);

        // 7. Execution
        try {
            await command.execute(interaction, client);

            // 8. Activity Streak Tracking (only on successful command execution)
            if (client.activityStreakService && interaction.guild) {
                try {
                    await client.activityStreakService.recordActivity(
                        interaction.user.id,
                        interaction.guild.id,
                        'command',
                        1
                    );

                    // Track unique command usage for Command Explorer achievement
                    await client.activityStreakService.recordCommandUsage(
                        interaction.user.id,
                        interaction.guild.id,
                        interaction.commandName
                    );
                } catch (trackError) {
                    logger.error('Activity streak tracking error:', trackError);
                    // Don't crash on tracking errors, just log
                }
            }
        } catch (error) {
            // Build detailed context for debugging
            const subcommand = interaction.options.getSubcommand(false);
            const subcommandGroup = interaction.options.getSubcommandGroup(false);
            let commandPath = interaction.commandName;
            if (subcommandGroup) commandPath += ` ${subcommandGroup}`;
            if (subcommand) commandPath += ` ${subcommand}`;

            // Extract options for context (avoid sensitive data)
            const options = {};
            try {
                interaction.options.data.forEach(opt => {
                    if (opt.type === 1) { // Subcommand
                        opt.options?.forEach(o => {
                            options[o.name] = o.value;
                        });
                    } else if (opt.type === 2) { // Subcommand Group
                        opt.options?.forEach(sub => {
                            sub.options?.forEach(o => {
                                options[o.name] = o.value;
                            });
                        });
                    } else {
                        options[opt.name] = opt.value;
                    }
                });
            } catch { }

            logger.errorContext(`Error executing command: ${commandPath}`, error, {
                command: commandPath,
                options: Object.keys(options).length > 0 ? options : undefined,
                userId: interaction.user?.id,
                guildId: interaction.guildId,
                channelId: interaction.channelId
            });

            const errorMessage = embeds.error('Critical Error', 'An unexpected error occurred while executing this command. The developers have been notified.');

            try {
                if (interaction.replied || interaction.deferred) {
                    await interaction.followUp({ embeds: [errorMessage], flags: [MessageFlags.Ephemeral] });
                } else {
                    await interaction.reply({ embeds: [errorMessage], flags: [MessageFlags.Ephemeral] });
                }
            } catch (replyError) {
                // Interaction expired or already handled - log but don't crash
                logger.debug(`Could not send error response: ${replyError.message}`);
            }
        }
    },
};
