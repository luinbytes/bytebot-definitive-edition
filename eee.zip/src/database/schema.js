const { sqliteTable, text, integer, real, index, unique, primaryKey } = require('drizzle-orm/sqlite-core');

const guilds = sqliteTable('guilds', {
    id: text('id').primaryKey(),
    prefix: text('prefix').default('!'),
    logChannel: text('log_channel'),
    welcomeChannel: text('welcome_channel'),
    welcomeMessage: text('welcome_message'),
    welcomeEnabled: integer('welcome_enabled', { mode: 'boolean' }).default(false),
    welcomeUseEmbed: integer('welcome_use_embed', { mode: 'boolean' }).default(true),
    joinedAt: integer('joined_at', { mode: 'timestamp' }),
    voiceHubChannelId: text('voice_hub_channel_id'),
    voiceHubCategoryId: text('voice_hub_category_id'),
    achievementsEnabled: integer('achievements_enabled', { mode: 'boolean' }).default(true), // Guild-level achievement toggle
});

const users = sqliteTable('users', {
    id: text('id').primaryKey(),
    guildId: text('guild_id').notNull(),
    commandsRun: integer('commands_run').default(0),
    lastSeen: integer('last_seen', { mode: 'timestamp' }),
    wtNickname: text('wt_nickname'),
    ephemeralPreference: text('ephemeral_preference').default('default'), // 'always' | 'public' | 'default'
    achievementsOptedOut: integer('achievements_opted_out', { mode: 'boolean' }).default(false), // Global opt-out from achievement tracking
});

const moderationLogs = sqliteTable('moderation_logs', {
    id: integer('id').primaryKey({ autoIncrement: true }),
    guildId: text('guild_id').notNull(),
    targetId: text('target_id').notNull(),
    executorId: text('executor_id').notNull(),
    action: text('action').notNull(), // 'KICK', 'BAN', 'CLEAR', etc.
    reason: text('reason'),
    timestamp: integer('timestamp', { mode: 'timestamp' }).default(new Date()),
});

const commandPermissions = sqliteTable('command_permissions', {
    id: integer('id').primaryKey({ autoIncrement: true }),
    guildId: text('guild_id').notNull(),
    commandName: text('command_name').notNull(),
    roleId: text('role_id').notNull(),
});

const bytepods = sqliteTable('bytepods', {
    channelId: text('channel_id').primaryKey(),
    guildId: text('guild_id').notNull(),
    ownerId: text('owner_id').notNull(),
    originalOwnerId: text('original_owner_id'), // Who created the pod (for reclaim eligibility)
    ownerLeftAt: integer('owner_left_at'),      // Timestamp (ms) when owner left - null if owner present
    reclaimRequestPending: integer('reclaim_request_pending', { mode: 'boolean' }).default(false), // Prevents duplicate reclaim prompts
    panelMessageId: text('panel_message_id'), // Message ID of the active control panel (for cleanup)
    createdAt: integer('created_at', { mode: 'timestamp' }).default(new Date()),
});

const bytepodAutoWhitelist = sqliteTable('bytepod_autowhitelist', {
    id: integer('id').primaryKey({ autoIncrement: true }),
    userId: text('user_id').notNull(),
    targetUserId: text('target_user_id').notNull(),
    guildId: text('guild_id'),
});

const bytepodUserSettings = sqliteTable('bytepod_user_settings', {
    userId: text('user_id').notNull(),
    guildId: text('guild_id').notNull(),
    autoLock: integer('auto_lock', { mode: 'boolean' }).default(false),
    summaryEnabled: integer('summary_enabled', { mode: 'boolean' }).default(false), // Receive BytePod session summaries via DM
    podNameStyle: text('pod_name_style').default('username'), // 'username' | 'random'
}, (table) => ({
    // Composite primary key: one setting per user per guild
    pk: primaryKey({ columns: [table.userId, table.guildId] }),
}));

// Active voice sessions (persisted - survives bot restarts)
const bytepodActiveSessions = sqliteTable('bytepod_active_sessions', {
    id: integer('id').primaryKey({ autoIncrement: true }),
    podId: text('pod_id').notNull(),       // References bytepods.channelId
    userId: text('user_id').notNull(),
    guildId: text('guild_id').notNull(),
    startTime: integer('start_time').notNull(), // Unix timestamp ms
});

// Voice activity stats (per-user, per-guild aggregate)
const bytepodVoiceStats = sqliteTable('bytepod_voice_stats', {
    id: integer('id').primaryKey({ autoIncrement: true }),
    userId: text('user_id').notNull(),
    guildId: text('guild_id').notNull(),
    totalSeconds: integer('total_seconds').default(0),
    sessionCount: integer('session_count').default(0),
});

// Template presets (saved channel configurations)
const bytepodTemplates = sqliteTable('bytepod_templates', {
    id: integer('id').primaryKey({ autoIncrement: true }),
    userId: text('user_id').notNull(),
    guildId: text('guild_id').notNull(),
    name: text('name').notNull(),
    userLimit: integer('user_limit').default(0),
    autoLock: integer('auto_lock', { mode: 'boolean' }).default(false),
    whitelistUserIds: text('whitelist_user_ids'), // JSON stringified array
}, (table) => ({
    // Composite unique constraint: one template name per user per guild
    userGuildNameUnique: unique().on(table.userId, table.guildId, table.name),
}));

// Session history (archived pod sessions for stats/analytics)
const bytepodSessionHistory = sqliteTable('bytepod_session_history', {
    id: integer('id').primaryKey({ autoIncrement: true }),
    podId: text('pod_id').notNull(),
    guildId: text('guild_id').notNull(),
    ownerId: text('owner_id').notNull(),
    podName: text('pod_name'),
    startedAt: integer('started_at', { mode: 'timestamp' }).notNull(),
    endedAt: integer('ended_at', { mode: 'timestamp' }).notNull(),
    peakUsers: integer('peak_users').default(1),
    uniqueVisitors: integer('unique_visitors').default(1),
    totalVoiceMinutes: integer('total_voice_minutes').default(0),
    visitorData: text('visitor_data'), // JSON: [{userId, durationSeconds}]
}, (table) => ({
    // Index for owner session history queries
    ownerIdx: index('bytepod_session_owner_idx').on(table.ownerId, table.guildId),
    // Index for guild analytics
    guildIdx: index('bytepod_session_guild_idx').on(table.guildId, table.endedAt),
}));

// Birthday tracking (per-user, per-guild)
const birthdays = sqliteTable('birthdays', {
    id: integer('id').primaryKey({ autoIncrement: true }),
    userId: text('user_id').notNull(),
    guildId: text('guild_id').notNull(),
    month: integer('month').notNull(), // 1-12
    day: integer('day').notNull(),     // 1-31
    createdAt: integer('created_at', { mode: 'timestamp' }).default(new Date()),
}, (table) => ({
    // Composite unique constraint: one birthday per user per guild
    userGuildUnique: unique().on(table.userId, table.guildId),
    // Index for daily birthday queries
    guildMonthDayIdx: index('birthdays_guild_month_day_idx').on(table.guildId, table.month, table.day),
    // Index for user lookups
    userGuildIdx: index('birthdays_user_guild_idx').on(table.userId, table.guildId),
}));

// Birthday announcement configuration (per-guild)
const birthdayConfig = sqliteTable('birthday_config', {
    guildId: text('guild_id').primaryKey(),
    channelId: text('channel_id').notNull(),
    roleId: text('role_id'), // Optional birthday role
    enabled: integer('enabled', { mode: 'boolean' }).default(true).notNull(),
    lastCheck: integer('last_check', { mode: 'timestamp' }), // Last midnight check
});

// Message bookmarks (per-user, cross-guild)
const bookmarks = sqliteTable('bookmarks', {
    id: integer('id').primaryKey({ autoIncrement: true }),
    userId: text('user_id').notNull(),
    guildId: text('guild_id').notNull(),
    channelId: text('channel_id').notNull(),
    messageId: text('message_id').notNull(),
    content: text('content').notNull(), // Cached message content
    authorId: text('author_id').notNull(), // Original message author
    attachmentUrls: text('attachment_urls'), // JSON array of attachment URLs
    savedAt: integer('saved_at', { mode: 'timestamp' }).default(new Date()),
    messageDeleted: integer('message_deleted', { mode: 'boolean' }).default(false).notNull()
}, (table) => ({
    // Index for user's bookmark list (sorted by saved date)
    userSavedIdx: index('bookmarks_user_saved_idx').on(table.userId, table.savedAt),
    // Index for search queries
    userContentIdx: index('bookmarks_user_content_idx').on(table.userId, table.content),
}));

// Auto-responder (keyword-based automated responses)
const autoResponses = sqliteTable('auto_responses', {
    id: integer('id').primaryKey({ autoIncrement: true }),
    guildId: text('guild_id').notNull(),
    trigger: text('trigger').notNull(), // Keyword or pattern
    response: text('response').notNull(), // Response text (max 2000 chars)
    channelId: text('channel_id'), // null = guild-wide
    creatorId: text('creator_id').notNull(),
    enabled: integer('enabled', { mode: 'boolean' }).default(true).notNull(),
    cooldown: integer('cooldown').default(60), // Seconds between triggers
    matchType: text('match_type').default('contains').notNull(), // exact, contains, wildcard, regex
    requireRoleId: text('require_role_id'), // null = any user
    useCount: integer('use_count').default(0), // Analytics
    createdAt: integer('created_at', { mode: 'timestamp' }).default(new Date()),
    lastUsed: integer('last_used', { mode: 'timestamp' })
}, (table) => ({
    // Index for active response lookups
    guildEnabledIdx: index('autoresponse_guild_enabled_idx').on(table.guildId, table.enabled),
    // Index for channel-specific responses
    guildChannelIdx: index('autoresponse_guild_channel_idx').on(table.guildId, table.channelId),
}));

// Starboard configuration (per-guild)
const starboardConfig = sqliteTable('starboard_config', {
    guildId: text('guild_id').primaryKey(),
    channelId: text('channel_id').notNull(),
    threshold: integer('threshold').default(5).notNull(), // Stars needed to be featured
    emoji: text('emoji').default('⭐').notNull(), // Reaction emoji to track
    enabled: integer('enabled', { mode: 'boolean' }).default(true).notNull()
});

// Starboard messages (tracks starred messages)
const starboardMessages = sqliteTable('starboard_messages', {
    id: integer('id').primaryKey({ autoIncrement: true }),
    guildId: text('guild_id').notNull(),
    originalMessageId: text('original_message_id').notNull().unique(), // Original message ID
    originalChannelId: text('original_channel_id').notNull(),
    starboardMessageId: text('starboard_message_id'), // Message ID in starboard channel (null if removed)
    authorId: text('author_id').notNull(),
    starCount: integer('star_count').default(0).notNull(),
    content: text('content'), // Cached content
    imageUrl: text('image_url'), // First image attachment URL
    postedAt: integer('posted_at', { mode: 'timestamp_ms' }).notNull()
}, (table) => ({
    // Index for leaderboard queries (top starred messages)
    guildStarCountIdx: index('starboard_guild_starcount_idx').on(table.guildId, table.starCount),
    // Index for author stats
    authorGuildIdx: index('starboard_author_guild_idx').on(table.authorId, table.guildId),
}));

const honeypotConfig = sqliteTable('honeypot_config', {
    guildId: text('guild_id').primaryKey(),
    categoryId: text('category_id'),
    channelId: text('channel_id').unique(),
    warningMessageId: text('warning_message_id'),
    shameBoardMessageId: text('shame_board_message_id'),
    enabled: integer('enabled', { mode: 'boolean' }).default(false).notNull(),
    pinWarningFailed: integer('pin_warning_failed', { mode: 'boolean' }).default(false).notNull(),
    createdAt: integer('created_at', { mode: 'timestamp' }).default(new Date()),
    updatedAt: integer('updated_at', { mode: 'timestamp' }).default(new Date())
}, (table) => ({
    channelIdx: index('honeypot_config_channel_idx').on(table.channelId),
    enabledChannelIdx: index('honeypot_config_enabled_channel_idx').on(table.enabled, table.channelId)
}));

const honeypotExemptUsers = sqliteTable('honeypot_exempt_users', {
    id: integer('id').primaryKey({ autoIncrement: true }),
    guildId: text('guild_id').notNull(),
    userId: text('user_id').notNull()
}, (table) => ({
    guildUserUnique: unique().on(table.guildId, table.userId),
    guildIdx: index('honeypot_exempt_users_guild_idx').on(table.guildId)
}));

const honeypotExemptRoles = sqliteTable('honeypot_exempt_roles', {
    id: integer('id').primaryKey({ autoIncrement: true }),
    guildId: text('guild_id').notNull(),
    roleId: text('role_id').notNull()
}, (table) => ({
    guildRoleUnique: unique().on(table.guildId, table.roleId),
    guildIdx: index('honeypot_exempt_roles_guild_idx').on(table.guildId)
}));

const honeypotIncidents = sqliteTable('honeypot_incidents', {
    id: integer('id').primaryKey({ autoIncrement: true }),
    guildId: text('guild_id').notNull(),
    userId: text('user_id').notNull(),
    username: text('username'),
    displayName: text('display_name'),
    messageId: text('message_id'),
    channelId: text('channel_id').notNull(),
    snippet: text('snippet'),
    attachmentSummary: text('attachment_summary'),
    status: text('status').notNull(),
    failureReason: text('failure_reason'),
    accountCreatedAt: integer('account_created_at', { mode: 'timestamp' }),
    joinedAt: integer('joined_at', { mode: 'timestamp' }),
    triggeredAt: integer('triggered_at', { mode: 'timestamp' }).default(new Date()).notNull()
}, (table) => ({
    guildTriggeredIdx: index('honeypot_incidents_guild_triggered_idx').on(table.guildId, table.triggeredAt),
    guildStatusIdx: index('honeypot_incidents_guild_status_idx').on(table.guildId, table.status)
}));

// Reminders (scheduled user notifications)
const reminders = sqliteTable('reminders', {
    id: integer('id').primaryKey({ autoIncrement: true }),
    userId: text('user_id').notNull(),
    guildId: text('guild_id'), // null for DM reminders
    channelId: text('channel_id'), // null for DM reminders
    message: text('message').notNull(),
    triggerAt: integer('trigger_at', { mode: 'timestamp_ms' }).notNull(),
    createdAt: integer('created_at', { mode: 'timestamp_ms' }).notNull(),
    active: integer('active', { mode: 'boolean' }).default(true).notNull()
}, (table) => ({
    // Index for user reminder list queries
    userActiveIdx: index('reminders_user_active_idx').on(table.userId, table.active),
    // Index for scheduler queries (upcoming reminders)
    triggerIdx: index('reminders_trigger_idx').on(table.triggerAt, table.active),
    // Index for guild cleanup
    guildIdx: index('reminders_guild_idx').on(table.guildId, table.active)
}));

// Suggestions configuration (per-guild)
const suggestionConfig = sqliteTable('suggestion_config', {
    guildId: text('guild_id').primaryKey(),
    channelId: text('channel_id').notNull(),
    reviewRoleId: text('review_role_id'), // Role that can approve/deny (null = Admin only)
    enabled: integer('enabled', { mode: 'boolean' }).default(true).notNull(),
    allowAnonymous: integer('allow_anonymous', { mode: 'boolean' }).default(false).notNull()
});

// Suggestions (community ideas/feedback)
const suggestions = sqliteTable('suggestions', {
    id: integer('id').primaryKey({ autoIncrement: true }),
    guildId: text('guild_id').notNull(),
    userId: text('user_id').notNull(), // Suggester
    content: text('content').notNull(), // Suggestion text (max 2000 chars)
    messageId: text('message_id').notNull(), // Message ID in suggestion channel
    channelId: text('channel_id').notNull(), // Suggestion channel ID
    status: text('status').default('pending').notNull(), // pending, approved, denied, implemented
    upvotes: integer('upvotes').default(0), // Cached vote count
    downvotes: integer('downvotes').default(0), // Cached vote count
    reviewedBy: text('reviewed_by'), // Admin who approved/denied
    reviewedAt: integer('reviewed_at', { mode: 'timestamp' }), // When admin took action
    reviewReason: text('review_reason'), // Optional reason for approval/denial
    createdAt: integer('created_at', { mode: 'timestamp' }).default(new Date()),
    anonymous: integer('anonymous', { mode: 'boolean' }).default(false).notNull() // Hide suggester name
}, (table) => ({
    // Index for guild suggestion list queries
    guildStatusIdx: index('suggestions_guild_status_idx').on(table.guildId, table.status),
    // Index for user suggestion list queries
    userGuildIdx: index('suggestions_user_guild_idx').on(table.userId, table.guildId),
    // Index for leaderboard queries (top voted)
    guildUpvotesIdx: index('suggestions_guild_upvotes_idx').on(table.guildId, table.upvotes)
}));

// Activity Streaks (daily engagement tracking)
const activityStreaks = sqliteTable('activity_streaks', {
    id: integer('id').primaryKey({ autoIncrement: true }),
    userId: text('user_id').notNull(),
    guildId: text('guild_id').notNull(),
    currentStreak: integer('current_streak').default(0).notNull(), // Consecutive active days
    longestStreak: integer('longest_streak').default(0).notNull(), // All-time best streak
    lastActivityDate: text('last_activity_date'), // YYYY-MM-DD format
    totalActiveDays: integer('total_active_days').default(0).notNull(),
    freezesAvailable: integer('freezes_available').default(1).notNull(), // Streak freeze items (1 per month)
    lastFreezeReset: integer('last_freeze_reset', { mode: 'timestamp' }), // Monthly reset tracker
    createdAt: integer('created_at', { mode: 'timestamp' }).default(new Date()),
    updatedAt: integer('updated_at', { mode: 'timestamp' }).default(new Date())
}, (table) => ({
    // Composite unique constraint: one streak record per user per guild
    userGuildUnique: unique().on(table.userId, table.guildId),
    // Index for guild leaderboard queries (current streak)
    guildCurrentStreakIdx: index('streaks_guild_current_idx').on(table.guildId, table.currentStreak),
    // Index for longest streak leaderboard
    guildLongestStreakIdx: index('streaks_guild_longest_idx').on(table.guildId, table.longestStreak),
    // Index for user lookups
    userGuildIdx: index('streaks_user_guild_idx').on(table.userId, table.guildId)
}));

// Activity Achievements (milestone rewards)
const activityAchievements = sqliteTable('activity_achievements', {
    id: integer('id').primaryKey({ autoIncrement: true }),
    userId: text('user_id').notNull(),
    guildId: text('guild_id').notNull(),
    achievementId: text('achievement_id').notNull(), // e.g., "streak_7", "streak_30", "total_100"
    notified: integer('notified', { mode: 'boolean' }).default(false).notNull(), // Has user been DM'd?
    points: integer('points').default(0).notNull(), // Points value of achievement
    awardedBy: text('awarded_by'), // null = auto-tracked, userId = manually awarded by admin
    earnedAt: integer('earned_at', { mode: 'timestamp' }).default(new Date())
}, (table) => ({
    // Composite unique constraint: one achievement per user per guild
    userGuildAchievementUnique: unique().on(table.userId, table.guildId, table.achievementId),
    // Index for user achievement list
    userGuildIdx: index('achievements_user_guild_idx').on(table.userId, table.guildId),
    // Index for achievement type queries
    achievementIdx: index('achievements_type_idx').on(table.achievementId)
}));

// Daily Activity Log (tracks activity types per day)
const activityLogs = sqliteTable('activity_logs', {
    id: integer('id').primaryKey({ autoIncrement: true }),
    userId: text('user_id').notNull(),
    guildId: text('guild_id').notNull(),
    activityDate: text('activity_date').notNull(), // YYYY-MM-DD format
    messageCount: integer('message_count').default(0).notNull(),
    voiceMinutes: integer('voice_minutes').default(0).notNull(),
    commandsRun: integer('commands_run').default(0).notNull(),
    reactionsGiven: integer('reactions_given').default(0).notNull(), // Track reactions given
    channelsJoined: integer('channels_joined').default(0).notNull(), // Track unique voice channels joined
    bytepodsCreated: integer('bytepods_created').default(0).notNull(), // Track BytePods created
    uniqueCommandsUsed: text('unique_commands_used'), // JSON array of unique command names
    activeHours: text('active_hours'), // JSON array of hours (0-23) when user was active
    firstActivityTime: integer('first_activity_time'), // Unix timestamp of first activity this day
    lastActivityTime: integer('last_activity_time'), // Unix timestamp of last activity this day
    updatedAt: integer('updated_at', { mode: 'timestamp' }).default(new Date())
}, (table) => ({
    // Composite unique constraint: one log per user per guild per day
    userGuildDateUnique: unique().on(table.userId, table.guildId, table.activityDate),
    // Index for user activity history
    userGuildDateIdx: index('activity_user_guild_date_idx').on(table.userId, table.guildId, table.activityDate),
    // Index for daily cleanup queries
    dateIdx: index('activity_date_idx').on(table.activityDate)
}));

// Achievement Definitions (metadata for all achievements - core + seasonal)
const achievementDefinitions = sqliteTable('achievement_definitions', {
    id: text('id').primaryKey(), // e.g., "message_1000", "streak_365"
    title: text('title').notNull(),
    description: text('description').notNull(),
    emoji: text('emoji').notNull(),
    category: text('category').notNull(), // streak, total, message, voice, command, special, social, combo, meta, custom
    rarity: text('rarity').notNull(), // common, uncommon, rare, epic, legendary, mythic
    checkType: text('check_type').notNull(), // exact, threshold, special, combo, time-based, manual
    criteria: text('criteria').notNull(), // JSON: {"messageCount": 1000} or {"streak": 7}
    grantRole: integer('grant_role', { mode: 'boolean' }).default(false).notNull(), // Grant role reward?
    points: integer('points').default(0).notNull(), // Point value
    startDate: integer('start_date', { mode: 'timestamp' }), // When achievement becomes available (seasonal)
    endDate: integer('end_date', { mode: 'timestamp' }), // When achievement expires (seasonal)
    seasonal: integer('seasonal', { mode: 'boolean' }).default(false).notNull(), // Is time-limited?
    seasonalEvent: text('seasonal_event'), // halloween, christmas, anniversary, etc.
    createdAt: integer('created_at', { mode: 'timestamp' }).default(new Date())
}, (table) => ({
    // Index for category-based queries
    categoryIdx: index('achievement_defs_category_idx').on(table.category),
    // Index for rarity filtering
    rarityIdx: index('achievement_defs_rarity_idx').on(table.rarity),
    // Index for seasonal achievement queries
    seasonalIdx: index('achievement_defs_seasonal_idx').on(table.seasonal, table.startDate, table.endDate)
}));

// Achievement Role Configuration (per-guild settings for role rewards)
const achievementRoleConfig = sqliteTable('achievement_role_config', {
    guildId: text('guild_id').primaryKey(),
    enabled: integer('enabled', { mode: 'boolean' }).default(true).notNull(), // Enable role rewards
    rolePrefix: text('role_prefix').default('🏆').notNull(), // Role name prefix
    useRarityColors: integer('use_rarity_colors', { mode: 'boolean' }).default(true).notNull(), // Color by rarity vs brand color
    cleanupOrphaned: integer('cleanup_orphaned', { mode: 'boolean' }).default(true).notNull(), // Delete roles with 0 members
    notifyOnEarn: integer('notify_on_earn', { mode: 'boolean' }).default(true).notNull(), // Send DM notifications
    createdAt: integer('created_at', { mode: 'timestamp' }).default(new Date()),
    updatedAt: integer('updated_at', { mode: 'timestamp' }).default(new Date())
});

// Achievement Roles (track dynamically created achievement roles)
const achievementRoles = sqliteTable('achievement_roles', {
    id: integer('id').primaryKey({ autoIncrement: true }),
    achievementId: text('achievement_id').notNull(), // FK to achievementDefinitions.id
    guildId: text('guild_id').notNull(),
    roleId: text('role_id').notNull(), // Discord role ID
    createdAt: integer('created_at', { mode: 'timestamp' }).default(new Date())
}, (table) => ({
    // Composite unique constraint: one role per achievement per guild
    achievementGuildUnique: unique().on(table.achievementId, table.guildId),
    // Index for guild role queries
    guildIdx: index('achievement_roles_guild_idx').on(table.guildId),
    // Index for achievement lookups
    achievementIdx: index('achievement_roles_achievement_idx').on(table.achievementId)
}));

// Custom Achievements (server-created custom achievements)
const customAchievements = sqliteTable('custom_achievements', {
    id: integer('id').primaryKey({ autoIncrement: true }),
    guildId: text('guild_id').notNull(),
    achievementId: text('achievement_id').notNull(), // custom_guild123_timestamp
    title: text('title').notNull(),
    description: text('description').notNull(),
    emoji: text('emoji').notNull(),
    category: text('category').default('custom').notNull(),
    rarity: text('rarity').notNull(), // common, uncommon, rare, epic, legendary, mythic
    checkType: text('check_type').notNull(), // manual, auto (message/voice/event)
    criteria: text('criteria'), // JSON for auto-check (null for manual)
    grantRole: integer('grant_role', { mode: 'boolean' }).default(false).notNull(),
    points: integer('points').notNull(),
    createdBy: text('created_by').notNull(), // Admin who created it
    createdAt: integer('created_at', { mode: 'timestamp' }).default(new Date()),
    enabled: integer('enabled', { mode: 'boolean' }).default(true).notNull()
}, (table) => ({
    // Composite unique constraint: unique achievement ID per guild
    guildAchievementUnique: unique().on(table.guildId, table.achievementId),
    // Index for guild custom achievement queries
    guildIdx: index('custom_achievements_guild_idx').on(table.guildId),
    // Index for enabled achievements
    guildEnabledIdx: index('custom_achievements_guild_enabled_idx').on(table.guildId, table.enabled)
}));

module.exports = {
    guilds,
    users,
    moderationLogs,
    commandPermissions,
    bytepods,
    bytepodAutoWhitelist,
    bytepodUserSettings,
    bytepodActiveSessions,
    bytepodVoiceStats,
    bytepodTemplates,
    bytepodSessionHistory,
    birthdays,
    birthdayConfig,
    bookmarks,
    autoResponses,
    starboardConfig,
    starboardMessages,
    honeypotConfig,
    honeypotExemptUsers,
    honeypotExemptRoles,
    honeypotIncidents,
    reminders,
    suggestionConfig,
    suggestions,
    activityStreaks,
    activityAchievements,
    activityLogs,
    achievementDefinitions,
    achievementRoleConfig,
    achievementRoles,
    customAchievements
};
