const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, MessageFlags } = require('discord.js');
const { db } = require('../../database/index');
const { guilds } = require('../../database/schema');
const { eq } = require('drizzle-orm');
const embeds = require('../../utils/embeds');
const { handleCommandError } = require('../../utils/errorHandlerUtil');
const { dbLog } = require('../../utils/dbLogger');
const { fetchChannel, safeChannelSend } = require('../../utils/discordApiUtil');

/**
 * Get ordinal suffix for a number (1st, 2nd, 3rd, etc.)
 * @param {number} num - The number
 * @returns {string}
 */
function getOrdinalSuffix(num) {
    const j = num % 10;
    const k = num % 100;
    if (j === 1 && k !== 11) return num + 'st';
    if (j === 2 && k !== 12) return num + 'nd';
    if (j === 3 && k !== 13) return num + 'rd';
    return num + 'th';
}

/**
 * Parse welcome message variables
 * @param {string} message - Message template with variables
 * @param {GuildMember} member - The member who joined
 * @param {Guild} guild - The guild the member joined
 * @returns {string}
 */
function parseWelcomeMessage(message, member, guild) {
    const now = new Date();
    const accountCreated = member.user.createdAt;
    const accountAgeDays = Math.floor((now - accountCreated) / (1000 * 60 * 60 * 24));
    const accountAgeMonths = Math.floor(accountAgeDays / 30);
    const joinedAt = member.joinedAt || now;

    // Format dates
    const joinedAtFormatted = joinedAt.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    const createdAtFormatted = accountCreated.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });

    // Relative timestamps for Discord (will show as "X days ago", "X months ago", etc.)
    const joinedTimestamp = `<t:${Math.floor(joinedAt.getTime() / 1000)}:R>`;
    const createdTimestamp = `<t:${Math.floor(accountCreated.getTime() / 1000)}:R>`;
    const joinedTimestampFull = `<t:${Math.floor(joinedAt.getTime() / 1000)}:F>`;
    const createdTimestampFull = `<t:${Math.floor(accountCreated.getTime() / 1000)}:F>`;

    return message
        // User mentions
        .replace(/{user}/g, `<@${member.id}>`)
        .replace(/{mention}/g, `<@${member.id}>`)
        .replace(/{username}/g, member.user.username)
        .replace(/{tag}/g, member.user.tag)
        .replace(/{displayname}/g, member.displayName)

        // Server info
        .replace(/{server}/g, guild.name)
        .replace(/{memberCount}/g, guild.memberCount.toString())
        .replace(/{membercount}/g, guild.memberCount.toString())
        .replace(/{memberNumber}/g, getOrdinalSuffix(guild.memberCount))
        .replace(/{membernumber}/g, getOrdinalSuffix(guild.memberCount))

        // Join date/time
        .replace(/{joinedAt}/g, joinedAtFormatted)
        .replace(/{joinedat}/g, joinedAtFormatted)
        .replace(/{joinedRelative}/g, joinedTimestamp)
        .replace(/{joinedrelative}/g, joinedTimestamp)
        .replace(/{joinedFull}/g, joinedTimestampFull)
        .replace(/{joinedfull}/g, joinedTimestampFull)

        // Account creation
        .replace(/{createdAt}/g, createdAtFormatted)
        .replace(/{createdat}/g, createdAtFormatted)
        .replace(/{createdRelative}/g, createdTimestamp)
        .replace(/{createdrelative}/g, createdTimestamp)
        .replace(/{createdFull}/g, createdTimestampFull)
        .replace(/{createdfull}/g, createdTimestampFull)

        // Account age
        .replace(/{accountAgeDays}/g, accountAgeDays.toString())
        .replace(/{accountagedays}/g, accountAgeDays.toString())
        .replace(/{accountAgeMonths}/g, accountAgeMonths.toString())
        .replace(/{accountagemonths}/g, accountAgeMonths.toString());
}

module.exports = {
    register: false,
    data: new SlashCommandBuilder()
        .setName('welcome')
        .setDescription('Manage welcome messages for new members.')
        .setDMPermission(false)
        .addSubcommandGroup(group => group
            .setName('configure')
            .setDescription('Set up and maintain welcome messages')
            .addSubcommand(subcommand =>
                subcommand
                    .setName('channel')
                    .setDescription('Set the welcome channel')
                    .addChannelOption(option =>
                        option.setName('channel')
                            .setDescription('The channel to send welcome messages to')
                            .addChannelTypes(ChannelType.GuildText)
                            .setRequired(true)))
            .addSubcommand(subcommand =>
                subcommand
                    .setName('message')
                    .setDescription('Set the welcome message template')
                    .addStringOption(option =>
                        option.setName('text')
                            .setDescription('Message template (use {user} {username} {server} {memberCount})')
                            .setRequired(true)
                            .setMinLength(1)
                            .setMaxLength(2000)))
            .addSubcommand(subcommand =>
                subcommand
                    .setName('enabled')
                    .setDescription('Enable or disable welcome messages')
                    .addBooleanOption(option =>
                        option.setName('enabled')
                            .setDescription('Enable or disable')
                            .setRequired(true)))
            .addSubcommand(subcommand =>
                subcommand
                    .setName('format')
                    .setDescription('Toggle whether to use an embed for welcome messages')
                    .addBooleanOption(option =>
                        option.setName('use_embed')
                            .setDescription('Use embed format')
                            .setRequired(true))))
        .addSubcommandGroup(group => group
            .setName('preview')
            .setDescription('Preview and inspect welcome settings')
            .addSubcommand(subcommand =>
                subcommand
                    .setName('variables')
                    .setDescription('View all available placeholder variables and examples'))
            .addSubcommand(subcommand =>
                subcommand
                    .setName('test')
                    .setDescription('Send a test welcome message to see how it looks'))
            .addSubcommand(subcommand =>
                subcommand
                    .setName('view')
                    .setDescription('View current welcome message configuration')))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    permissions: [PermissionFlagsBits.ManageGuild],
    cooldown: 3,

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        try {
            await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

            // Fetch current config
            const [config] = await dbLog.select('guilds',
                () => db.select().from(guilds).where(eq(guilds.id, interaction.guild.id)),
                { guildId: interaction.guild.id }
            );

            if (!config) {
                return interaction.editReply({
                    embeds: [embeds.error('Error', 'Configuration not found for this server.')]
                });
            }

            switch (subcommand) {
                case 'channel':
                case 'setup':
                    await handleSetup(interaction, config);
                    break;

                case 'message':
                    await handleMessage(interaction, config);
                    break;

                case 'enabled':
                case 'toggle':
                    await handleToggle(interaction, config);
                    break;

                case 'format':
                case 'embed':
                    await handleEmbed(interaction, config);
                    break;

                case 'variables':
                    await handleVariables(interaction);
                    break;

                case 'test':
                    await handleTest(interaction, config);
                    break;

                case 'view':
                    await handleView(interaction, config);
                    break;
            }

        } catch (error) {
            await handleCommandError(error, interaction, 'processing welcome configuration');
        }
    },
};

/**
 * Handle setup subcommand
 */
async function handleSetup(interaction, config) {
    const channel = interaction.options.getChannel('channel');

    // Check bot permissions in the target channel
    const botPermissions = channel.permissionsFor(interaction.guild.members.me);
    if (!botPermissions.has([PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks])) {
        return interaction.editReply({
            embeds: [embeds.error('Missing Permissions', `I need **Send Messages** and **Embed Links** permissions in ${channel}.`)]
        });
    }

    await dbLog.update('guilds',
        () => db.update(guilds)
            .set({ welcomeChannel: channel.id })
            .where(eq(guilds.id, interaction.guild.id)),
        { guildId: interaction.guild.id, welcomeChannel: channel.id }
    );

    return interaction.editReply({
        embeds: [embeds.success('Welcome Channel Set', `Welcome messages will be sent to ${channel}.\n\nUse \`/welcome message\` to set a custom message, then \`/welcome toggle\` to enable.`)]
    });
}

/**
 * Handle message subcommand
 */
async function handleMessage(interaction, config) {
    const message = interaction.options.getString('text');

    await dbLog.update('guilds',
        () => db.update(guilds)
            .set({ welcomeMessage: message })
            .where(eq(guilds.id, interaction.guild.id)),
        { guildId: interaction.guild.id }
    );

    // Parse the message to show a preview
    const preview = parseWelcomeMessage(message, interaction.member, interaction.guild);

    const embed = embeds.success('Welcome Message Updated', 'Your welcome message has been set!')
        .addFields(
            { name: 'Template', value: `\`\`\`${message}\`\`\``, inline: false },
            { name: 'Preview', value: preview.length > 1024 ? preview.substring(0, 1021) + '...' : preview, inline: false },
            { name: 'Available Variables', value: '**User:** `{user}` `{username}` `{tag}` `{displayname}`\n**Server:** `{server}` `{memberCount}` `{memberNumber}`\n**Dates:** `{joinedAt}` `{joinedRelative}` `{createdAt}` `{accountAgeDays}`', inline: false }
        );

    return interaction.editReply({
        embeds: [embed]
    });
}

/**
 * Handle toggle subcommand
 */
async function handleToggle(interaction, config) {
    const enabled = interaction.options.getBoolean('enabled');

    // Check if channel is configured
    if (enabled && !config.welcomeChannel) {
        return interaction.editReply({
            embeds: [embeds.error('Channel Not Set', 'Please use `/welcome setup` to set a welcome channel first.')]
        });
    }

    await dbLog.update('guilds',
        () => db.update(guilds)
            .set({ welcomeEnabled: enabled })
            .where(eq(guilds.id, interaction.guild.id)),
        { guildId: interaction.guild.id, welcomeEnabled: enabled }
    );

    const statusText = enabled ? 'enabled' : 'disabled';
    const emoji = enabled ? '✅' : '❌';

    return interaction.editReply({
        embeds: [embeds.success(`Welcome Messages ${enabled ? 'Enabled' : 'Disabled'}`, `${emoji} Welcome messages are now **${statusText}**.`)]
    });
}

/**
 * Handle embed subcommand
 */
async function handleEmbed(interaction, config) {
    const useEmbed = interaction.options.getBoolean('use_embed');

    await dbLog.update('guilds',
        () => db.update(guilds)
            .set({ welcomeUseEmbed: useEmbed })
            .where(eq(guilds.id, interaction.guild.id)),
        { guildId: interaction.guild.id, welcomeUseEmbed: useEmbed }
    );

    const formatText = useEmbed ? 'branded embed' : 'plain text';

    return interaction.editReply({
        embeds: [embeds.success('Welcome Format Updated', `Welcome messages will now be sent as **${formatText}**.`)]
    });
}

/**
 * Handle variables subcommand
 */
async function handleVariables(interaction) {
    const embed = embeds.brand('Welcome Message Variables', 'Use these placeholders in your welcome message. Copy and paste them into `/welcome message`.')
        .addFields(
            {
                name: '👤 User Information',
                value: '`{user}` - Mentions the user (@User)\n' +
                       '`{username}` - User\'s name without tag (JohnDoe)\n' +
                       '`{tag}` - Full username with tag (JohnDoe#1234)\n' +
                       '`{displayname}` - Server nickname or username',
                inline: false
            },
            {
                name: '🏠 Server Information',
                value: '`{server}` - Server name\n' +
                       '`{memberCount}` - Total member count (42)\n' +
                       '`{memberNumber}` - Member position with ordinal (42nd, 1st, 100th)',
                inline: false
            },
            {
                name: '📅 Join Dates',
                value: '`{joinedAt}` - Full date (December 26, 2025)\n' +
                       '`{joinedRelative}` - Relative time (2 minutes ago)\n' +
                       '`{joinedFull}` - Discord timestamp with full format',
                inline: false
            },
            {
                name: '🎂 Account Information',
                value: '`{createdAt}` - Account creation date (January 1, 2020)\n' +
                       '`{createdRelative}` - Account age relative (5 years ago)\n' +
                       '`{createdFull}` - Discord timestamp with full format\n' +
                       '`{accountAgeDays}` - Account age in days (1826)\n' +
                       '`{accountAgeMonths}` - Account age in months (60)',
                inline: false
            },
            {
                name: '💡 Example Message',
                value: '```Welcome to {server}, {user}! You\'re our {memberNumber} member. Your account was created {createdRelative}.```',
                inline: false
            },
            {
                name: '📝 Result',
                value: 'Welcome to ByteBot Server, @JohnDoe! You\'re our 42nd member. Your account was created 5 years ago.',
                inline: false
            }
        )
        .setFooter({ text: 'Use /welcome message to set your custom message' });

    return interaction.editReply({
        embeds: [embed]
    });
}

/**
 * Handle test subcommand
 */
async function handleTest(interaction, config) {
    // Check if channel is configured
    if (!config.welcomeChannel) {
        return interaction.editReply({
            embeds: [embeds.error('Channel Not Set', 'Please use `/welcome setup` to set a welcome channel first.')]
        });
    }

    const channel = await fetchChannel(interaction.guild, config.welcomeChannel, { logContext: 'welcome-test' });
    if (!channel) {
        return interaction.editReply({
            embeds: [embeds.error('Channel Not Found', 'The configured welcome channel no longer exists. Please run `/welcome setup` again.')]
        });
    }

    // Use custom message or default
    const messageTemplate = config.welcomeMessage || 'Welcome to **{server}**, {user}! You are member #{memberCount}.';
    const parsedMessage = parseWelcomeMessage(messageTemplate, interaction.member, interaction.guild);

    try {
        // Send test message based on embed preference
        let messageOptions;
        if (config.welcomeUseEmbed) {
            const welcomeEmbed = embeds.brand('Welcome!', parsedMessage)
                .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true, size: 256 }))
                .setFooter({ text: 'This is a test message' });
            messageOptions = { embeds: [welcomeEmbed] };
        } else {
            messageOptions = { content: `${parsedMessage}\n\n*This is a test message*` };
        }

        const sent = await safeChannelSend(channel, messageOptions, { logContext: 'welcome-test' });
        if (!sent) {
            return interaction.editReply({
                embeds: [embeds.error('Failed to Send', 'Could not send test message. Check bot permissions.')]
            });
        }

        return interaction.editReply({
            embeds: [embeds.success('Test Sent', `A test welcome message has been sent to ${channel}.`)]
        });

    } catch (error) {
        await handleCommandError(error, interaction, 'sending test welcome message');
    }
}

/**
 * Handle view subcommand
 */
async function handleView(interaction, config) {
    const embed = embeds.brand('Welcome Message Configuration', null)
        .addFields(
            {
                name: 'Status',
                value: config.welcomeEnabled ? '✅ Enabled' : '❌ Disabled',
                inline: true
            },
            {
                name: 'Channel',
                value: config.welcomeChannel ? `<#${config.welcomeChannel}>` : 'Not set',
                inline: true
            },
            {
                name: 'Format',
                value: config.welcomeUseEmbed ? 'Branded Embed' : 'Plain Text',
                inline: true
            },
            {
                name: 'Message Template',
                value: config.welcomeMessage
                    ? `\`\`\`${config.welcomeMessage}\`\`\``
                    : '*Default: Welcome to **{server}**, {user}! You are member #{memberCount}.*',
                inline: false
            },
            {
                name: 'Available Variables',
                value: '**User:** `{user}` `{username}` `{tag}` `{displayname}`\n' +
                       '**Server:** `{server}` `{memberCount}` `{memberNumber}`\n' +
                       '**Joined:** `{joinedAt}` `{joinedRelative}` `{joinedFull}`\n' +
                       '**Account:** `{createdAt}` `{createdRelative}` `{accountAgeDays}` `{accountAgeMonths}`',
                inline: false
            }
        );

    return interaction.editReply({
        embeds: [embed]
    });
}
