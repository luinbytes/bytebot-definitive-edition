const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { db } = require('../../database');
const { reminders } = require('../../database/schema');
const { eq, and, count } = require('drizzle-orm');
const embeds = require('../../utils/embeds');
const { parseTime, formatDuration } = require('../../utils/timeParser');
const { handleCommandError } = require('../../utils/errorHandlerUtil');

const MAX_REMINDERS_PER_USER = 25;

module.exports = {
    register: false,
    data: new SlashCommandBuilder()
        .setName('reminder')
        .setDescription('Set and manage reminders')
        .addSubcommandGroup(group => group
            .setName('create')
            .setDescription('Create new reminders')
            .addSubcommand(subcommand =>
                subcommand
                    .setName('me')
                    .setDescription('Set a personal DM reminder')
                    .addStringOption(option =>
                        option.setName('time')
                            .setDescription('Time until reminder (e.g., 10m, 2h, 3d, 2h 30m)')
                            .setRequired(true)
                    )
                    .addStringOption(option =>
                        option.setName('message')
                            .setDescription('What to remind you about')
                            .setRequired(true)
                            .setMaxLength(1000)
                    )
            )
            .addSubcommand(subcommand =>
                subcommand
                    .setName('here')
                    .setDescription('Set a reminder in this channel')
                    .addStringOption(option =>
                        option.setName('time')
                            .setDescription('Time until reminder (e.g., 10m, 2h, 3d, 2h 30m)')
                            .setRequired(true)
                    )
                    .addStringOption(option =>
                        option.setName('message')
                            .setDescription('What to remind about')
                            .setRequired(true)
                            .setMaxLength(1000)
                    )
            ))
        .addSubcommandGroup(group => group
            .setName('manage')
            .setDescription('Review and cancel reminders')
            .addSubcommand(subcommand =>
                subcommand
                    .setName('list')
                    .setDescription('View your active reminders')
            )
            .addSubcommand(subcommand =>
                subcommand
                    .setName('cancel')
                    .setDescription('Cancel a reminder')
                    .addIntegerOption(option =>
                        option.setName('id')
                            .setDescription('Reminder ID (from /reminder manage list)')
                            .setRequired(true)
                            .setMinValue(1)
                    )
            )),

    longRunning: true,
    deferEphemeral: true,

    async execute(interaction, client) {
        const subcommand = interaction.options.getSubcommand();

        switch (subcommand) {
            case 'me':
                await handleRemindMe(interaction, client);
                break;
            case 'here':
                await handleRemindHere(interaction, client);
                break;
            case 'list':
                await handleList(interaction, client);
                break;
            case 'cancel':
                await handleCancel(interaction, client);
                break;
        }
    }
};

/**
 * Handle /reminder me
 */
async function handleRemindMe(interaction, client) {
    const timeInput = interaction.options.getString('time');
    const message = interaction.options.getString('message');

    // Parse time
    const parsedTime = parseTime(timeInput);
    if (!parsedTime.success) {
        return interaction.editReply({
            embeds: [embeds.error('Invalid Time', parsedTime.error)]
        });
    }

    // Check user reminder count
    const countResult = await db.select({ count: count() })
        .from(reminders)
        .where(and(
            eq(reminders.userId, interaction.user.id),
            eq(reminders.active, true)
        ))
        .get();

    if (countResult.count >= MAX_REMINDERS_PER_USER) {
        return interaction.editReply({
            embeds: [embeds.error(
                'Reminder Limit Reached',
                `You have reached the maximum of ${MAX_REMINDERS_PER_USER} active reminders. Use \`/reminder list\` to manage them.`
            )]
        });
    }

    try {
        // Insert reminder
        const result = await db.insert(reminders).values({
            userId: interaction.user.id,
            guildId: null,
            channelId: null,
            message: message,
            triggerAt: new Date(parsedTime.timestamp),
            createdAt: new Date(),
            active: true
        }).returning().get();

        // Schedule reminder
        if (client.reminderService) {
            client.reminderService.scheduleReminder(result);
        }

        const embed = embeds.success(
            '✅ Reminder Set',
            `I'll remind you **<t:${Math.floor(parsedTime.timestamp / 1000)}:R>** (<t:${Math.floor(parsedTime.timestamp / 1000)}:F>)\n\n**Message:** ${message}`
        );
        embed.setFooter({ text: `Reminder ID: ${result.id} • Use /reminder cancel ${result.id} to cancel` });

        await interaction.editReply({ embeds: [embed] });

    } catch (error) {
        await handleCommandError(error, interaction, 'creating reminder');
    }
}

/**
 * Handle /reminder here
 */
async function handleRemindHere(interaction, client) {
    const timeInput = interaction.options.getString('time');
    const message = interaction.options.getString('message');

    // Check if in guild
    if (!interaction.guild) {
        return interaction.editReply({
            embeds: [embeds.error('Guild Only', 'Channel reminders can only be set in servers. Use `/reminder me` for DM reminders.')]
        });
    }

    // Check bot permissions in channel
    const botMember = await interaction.guild.members.fetch(client.user.id);
    const permissions = interaction.channel.permissionsFor(botMember);

    if (!permissions.has(PermissionFlagsBits.SendMessages)) {
        return interaction.editReply({
            embeds: [embeds.error(
                'Missing Permissions',
                "I don't have permission to send messages in this channel."
            )]
        });
    }

    // Parse time
    const parsedTime = parseTime(timeInput);
    if (!parsedTime.success) {
        return interaction.editReply({
            embeds: [embeds.error('Invalid Time', parsedTime.error)]
        });
    }

    // Check user reminder count
    const countResult = await db.select({ count: count() })
        .from(reminders)
        .where(and(
            eq(reminders.userId, interaction.user.id),
            eq(reminders.active, true)
        ))
        .get();

    if (countResult.count >= MAX_REMINDERS_PER_USER) {
        return interaction.editReply({
            embeds: [embeds.error(
                'Reminder Limit Reached',
                `You have reached the maximum of ${MAX_REMINDERS_PER_USER} active reminders. Use \`/reminder list\` to manage them.`
            )]
        });
    }

    try {
        // Insert reminder
        const result = await db.insert(reminders).values({
            userId: interaction.user.id,
            guildId: interaction.guild.id,
            channelId: interaction.channel.id,
            message: message,
            triggerAt: new Date(parsedTime.timestamp),
            createdAt: new Date(),
            active: true
        }).returning().get();

        // Schedule reminder
        if (client.reminderService) {
            client.reminderService.scheduleReminder(result);
        }

        const embed = embeds.success(
            '✅ Reminder Set',
            `I'll send a reminder in this channel **<t:${Math.floor(parsedTime.timestamp / 1000)}:R>** (<t:${Math.floor(parsedTime.timestamp / 1000)}:F>)\n\n**Message:** ${message}`
        );
        embed.setFooter({ text: `Reminder ID: ${result.id} • Use /reminder cancel ${result.id} to cancel` });

        await interaction.editReply({ embeds: [embed] });

    } catch (error) {
        await handleCommandError(error, interaction, 'creating channel reminder');
    }
}

/**
 * Handle /reminder list
 */
async function handleList(interaction, client) {
    try {
        const userReminders = await db.select()
            .from(reminders)
            .where(and(
                eq(reminders.userId, interaction.user.id),
                eq(reminders.active, true)
            ))
            .orderBy(reminders.triggerAt)
            .all();

        if (userReminders.length === 0) {
            return interaction.editReply({
                embeds: [embeds.warn(
                    'No Active Reminders',
                    'You have no active reminders. Use `/reminder me` or `/reminder here` to create one.'
                )]
            });
        }

        const embed = embeds.brand('📋 Your Active Reminders', null);

        const lines = await Promise.all(userReminders.map(async (reminder) => {
            const messagePreview = reminder.message.length > 50
                ? reminder.message.substring(0, 50) + '...'
                : reminder.message;

            let type = 'DM';
            if (reminder.channelId) {
                const channel = await client.channels.fetch(reminder.channelId).catch(() => null);
                type = channel ? `#${channel.name}` : 'deleted-channel';
            }

            return `**ID ${reminder.id}** • <t:${Math.floor(reminder.triggerAt / 1000)}:R>\n📍 ${type} • ${messagePreview}`;
        }));

        embed.setDescription(lines.join('\n\n'));
        embed.setFooter({ text: `${userReminders.length}/${MAX_REMINDERS_PER_USER} active reminders • Use /reminder cancel [id] to remove` });

        await interaction.editReply({ embeds: [embed] });

    } catch (error) {
        await handleCommandError(error, interaction, 'fetching reminders');
    }
}

/**
 * Handle /reminder cancel
 */
async function handleCancel(interaction, client) {
    const reminderId = interaction.options.getInteger('id');

    try {
        if (!client.reminderService) {
            return interaction.editReply({
                embeds: [embeds.error('Service Unavailable', 'Reminder service is not available.')]
            });
        }

        const cancelled = await client.reminderService.cancelReminder(reminderId, interaction.user.id);

        const embed = embeds.success(
            '✅ Reminder Cancelled',
            `Reminder #${reminderId} has been cancelled.\n\n**Was:** ${cancelled.message}`
        );

        await interaction.editReply({ embeds: [embed] });

    } catch (error) {
        await handleCommandError(error, interaction, 'cancelling reminder');
    }
}
